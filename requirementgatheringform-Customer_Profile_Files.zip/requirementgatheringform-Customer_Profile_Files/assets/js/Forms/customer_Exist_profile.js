$(document).ready(function () {
    
    $("#customer_type").val("Existing");
});
