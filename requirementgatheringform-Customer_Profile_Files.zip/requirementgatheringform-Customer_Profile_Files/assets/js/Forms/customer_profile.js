$(document).ready(function () {
    var customerType = $("#customer_type");
    var productType = $("#product_type");
    var pvesion = $("#product_version");
    var spocName = $("#spoc_name");
    var spoc_phno = $("#spoc_phno");
    var spoc_mail = $("#spoc_mail");
    var ba_name = $("#ba_name");
    var ba_phno = $("#ba_phno");
    var ba_mail = $("#ba_mail");
    var customer = $("#customer_name");
    var accNo = $("#acc_no");
    // var users = {}; // Your users object here

    init();

    /**
     * function use to Reverse Key and Values
     * @param {*} data 
     * @returns Object
     */
    const flip = (data) => Object.fromEntries(
        Object
        .entries(data)
        .map(([key, value]) => [value, key])
    );

    // Function to populate CustomerName
    function populateCustomerName(event, selectOption) {
        let Acct_no = selectOption.item.value;
        customer.val(newAcctNosDetails[Acct_no].name);
    }


    // Function to populate spoc details
    function populateSpocDetails(value) {
        spoc_phno.val(users.data[value].phone);
        spoc_phno.prop('disabled', true);
        spoc_mail.val(users.data[value].email);
        spoc_mail.prop('disabled', true);
    }

    // Function to populate ba details
    function populateBaDetails(value) {
        ba_phno.val(users.data[value].phone);
        ba_phno.prop('disabled', true);
        ba_mail.val(users.data[value].email);
        ba_mail.prop('disabled', true);
    }



    //Functoion handler for Account Numbers

    function populateAccountNos(type, val = '') {
        let options = '';
        if (type != 'New') {
            options = '<select class="form-select" aria-label="Default select example" id="acc_no" name="acc_no">';
            options += "<option vlaue=''>--select--</option>";

            for (key in CrmDetails) {
                options += "<option vlaue=" + key + ">" + CrmDetails[key] + "</option>";
            }
            options += "</select>";

        } else {
            options = '<input type="text" class="form-control" id="acc_no" name="acc_no"autocomplete="off">';

        }

        $("#AcctNoSpan").html(options);
        if (type != "New") {

            $("#acc_no").select2().on("select2:select", handleExistCustomer);

        } else
            setAccoutSuggestions();

    }


    /**
     * @fun used to set new Account no suggestion
     * 
     * @return null
     */
    function setAccoutSuggestions() {
        let newAcctNos = Object.values(newAcctNosDetails.AcctNos);
        $("#acc_no").autocomplete({
            source: newAcctNos,
            autofocus: true,
            select: populateCustomerName
        });
    }


    /**
     * @fun used to 
     * @return null
     */
    function handleExistCustomer(e) {
        existCrmNos = flip(CrmDetails);
        Account_no = e.params.data.id;
        profile_id = existCrmNos[Account_no];
        if (profile_id)
            window.location.href = `profile/${profile_id}`;
            
    }



    /**
     * 
     */
    function init() {
        // Event handler for spoc name change
        spocName.on("change", function () {
            let value = spocName.val();
            populateSpocDetails(value);
        });

        // Event handler for ba name change
        ba_name.on("change", function () {
            let value = ba_name.val();
            populateBaDetails(value);
        });

        accNo.on("change", function () {
            console.log("oko let start");
        });

        // Event handler for customer type change
        customerType.on("change", function () {
            type = customerType.val();
            populateAccountNos(type);
        });


        // Event handler for product type change
        productType.on("change", function () {
            var sel_product = productType.val();
            let options = '';
            $(products.productVersions[sel_product]).each(function (index, versions) {
                for (const key in versions) {
                    if (versions.hasOwnProperty.call(versions, key)) {
                        const version = versions[key];
                        options += '<option value=' + key + '>' + version + '</option>';
                    }
                }
            });
            pvesion.html(options);
            //   console.log("Customer type changed to: " + sel_product);
        });

        $("#ba_name").select2();
        $("#spoc_name").select2();
        setAccoutSuggestions();
    }

});