<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Suggestion extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id'   => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
            ],
            'Fid'  => [
                'type'       => 'INT',
                'constraint' => 10,
            ],
             'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
             'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);

        $this->forge->createTable('suggestion');
        $this->db->query("ALTER TABLE suggestion MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        $this->db->ForeignKeyChecks(1);
    }

    public function down()
    {
        //
        $this->forge->dropTable('suggestion');
    }
}
