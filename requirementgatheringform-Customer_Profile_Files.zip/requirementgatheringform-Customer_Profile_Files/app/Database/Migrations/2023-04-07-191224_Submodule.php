<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Submodule extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $this->db->ForeignKeyChecks(0);

        // $this->forge->addField('id');
        $this->forge->addField([
            'id'      => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'parent_id' => [
                'type' => 'INT',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        // $this->forge->addForeignKey('parent_id', 'dashBoardModules', 'id');
        $this->forge->createTable('sub_module');
        $this->db->query("ALTER TABLE sub_module MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
        $this->db->ForeignKeyChecks(1);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $this->forge->dropTable('sub_module');
    }
}
