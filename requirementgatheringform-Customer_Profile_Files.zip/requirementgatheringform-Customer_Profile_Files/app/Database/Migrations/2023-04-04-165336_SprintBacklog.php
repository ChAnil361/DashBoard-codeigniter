<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use Config\Database;

class SprintBacklog extends Migration
{ 
     /**
     * Run the migrations.
     */
    public function up(): void
    {
        $this->db->ForeignKeyChecks(0);

        $this->forge->addField([
            'id'                  => [
                'type'           => 'INT',
                'constraint'     => 10,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'product_Backlog_id'  => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
            ],
            'User_Story_Id'       => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
            ],
            'customer_id'         => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
            ],
            'Tab_Name'            => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
            ],
            'File_List'           => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'Menu_Name'           => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'Sub_Menu'            => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'Tables_List'         => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ], 
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        
        $this->forge->addForeignKey('product_Backlog_id', 'product_back_log', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('User_Story_Id', 'user_story', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('customer_id', 'customer_details', 'id', 'CASCADE', 'CASCADE');
      
        $this->forge->createTable('sprint_backlog', true);
        $this->db->query("ALTER TABLE sprint_backlog MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        $this->db->ForeignKeyChecks(1);

        // $this->db->enableForeignKeyChecks();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $this->forge->dropTable('sprint_backlog', true);
    }

}
