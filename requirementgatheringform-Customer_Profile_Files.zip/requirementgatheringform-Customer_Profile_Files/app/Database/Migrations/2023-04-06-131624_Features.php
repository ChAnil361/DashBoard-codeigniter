<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Features extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'unsigned' => true,
                'auto_increment' => true
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 30
            ],
            'DialingType' => [
                'type' => 'VARCHAR',
                'constraint' => 30
            ],
            'pid' => [
                'type' => 'INT',
                'unsigned' => true
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ], 
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('pid', 'productDetails', 'id');

        $this->forge->createTable('Features');
        $this->db->query("ALTER TABLE Features MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        $this->db->ForeignKeyChecks(1);
    }

    public function down()
    {
        //
        $this->forge->dropTable('Features');
    }
}
