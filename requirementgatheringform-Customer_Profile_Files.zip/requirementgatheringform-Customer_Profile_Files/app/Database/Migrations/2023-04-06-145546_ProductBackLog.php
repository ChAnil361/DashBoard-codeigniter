<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ProductBackLog extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'user_story_id' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
            ],
            'customer_id' => [
                'type' => 'BIGINT',
                'unsigned' => true,
            ],
            'module_id' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
            ],
            'smodule_id' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
            ],
            'feature_id' => [
                'type' => 'INT',
                'constraint' => 10,
                'unsigned' => true,
            ],
            'task_name' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
            ],
            'task_description' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'man_hours' => [
                'type' => 'INT',
                'constraint' => 5,
            ],
            'owner' => [
                'type' => 'VARCHAR',
                'constraint' => 20,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
             'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('user_story_id', 'user_story', 'id');
        $this->forge->addForeignKey('customer_id', 'customer_details', 'id');

        $this->forge->createTable('product_back_log');
        $this->db->query("ALTER TABLE product_back_log MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        
        $this->db->ForeignKeyChecks(1);
 
    }

    public function down()
    {
        //
        $this->forge->dropTable('product_back_log');
           }
}
