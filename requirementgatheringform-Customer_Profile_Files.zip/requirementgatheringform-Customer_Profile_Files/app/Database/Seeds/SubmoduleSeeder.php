<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SubmoduleSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Submodule 1',
                'parent_id' => 1,
            ],
            [
                'name' => 'Submodule 2',
                'parent_id' => 1,
            ],
            [
                'name' => 'Submodule 3',
                'parent_id' => 2,
            ],
            [
                'name' => 'Submodule 4',
                'parent_id' => 2,
            ],
        ];

        $this->db->table('sub_module')->insertBatch($data);
    }
}
