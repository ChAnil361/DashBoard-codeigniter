<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class IndustryDetailsSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Technology',
                'type' => 'IT',
            ],
            [
                'name' => 'Finance',
                'type' => 'Banking',
            ],
            [
                'name' => 'Manufacturing',
                'type' => 'Automobile',
            ],
        ];

        $this->db->table('industry_details')->insertBatch($data);
    }
}
