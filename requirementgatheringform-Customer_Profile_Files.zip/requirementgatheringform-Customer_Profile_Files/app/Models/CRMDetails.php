<?php

namespace App\Models;

// use CodeIgniter\Model;

use Illuminate\Database\Eloquent\Model;
use App\Models\CustomerDetail;

class CRMDetails extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'crmdetails'; 
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = \App\Entities\CRMDetailsEntity::class;
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function customerDetails()
    {
        return $this->hasMany(CustomerDetail::class, 'Cmr_id');
    }
    
     
    public function customer()
    {
        return $this->hasOne(CustomerDetail::class,'Cmr_id');
    }


    public function customer1()
    {
        return $this->hasMany(CustomerDetail::class,'Cmr_id');
    }


    // public function getProfile()
    // {
    //     $builder = $this->db->table($this->table);
    //       $builder->join($this->table2, "$this->table2.Cmr_id = $this->table.id");
    //    return $builder;
    //       // $query = $builder->get();

    //     // return $query->getResultArray();
    // }


    // public function getProfile()
    // {
    //    return  $this->belongsTo('\App\Models\CustomerDetail','Cmr_id');
    //     $builder = $this->db->table($this->table);
    //       $builder->join($this->table2, "$this->table2.Cmr_id = $this->table.id");
    //    return $builder;
    //       // $query = $builder->get();

    //     // return $query->getResultArray();
    // }

    /**
     * 
     */
    // public function  profile()
    // {
    //     return $this->hasOne('Cmr_id', '\App\Models\CustomerDetail');

    //  //   return $this->belongsTo('\App\Models\CustomerDetail','Cmr_id','id');
    // }

    
}
