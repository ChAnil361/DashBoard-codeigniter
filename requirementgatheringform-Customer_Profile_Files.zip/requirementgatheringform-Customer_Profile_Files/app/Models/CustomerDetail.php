<?php

namespace App\Models;

// use CodeIgniter\Model;
// use App\Entities\CustomerDetailsEntity;

use Illuminate\Database\Eloquent\Model;

class CustomerDetail extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'customerDetails';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = \App\Entities\CustomerDetailsEntity::class;
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    // protected $allowedFields    = ['id','CRM_Account_Number','CRM_Account_name','Product_id','industry_id','Hosting_Type','dialingType','Pusages','ba_id' ,'SPOC_id'];
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    
protected $customer_Type = ['New', 'Existing'];
protected $proposed_system = ['Standalone', 'Distributed'];
protected $setups = ['On Premises', 'Hosted', 'Cloud', 'Hybrid'];
protected $usage=['Product sales(Outbound)','Support & Services(Inbound)'];
 



    /**
     * 
     */
    public function crmDetails()
    {
        return $this->hasOne(CRMDetails::class,'id','Cmr_id');
    }
    

    public function product()
    {
        return $this->hasOne(ProductDetail::class,'id');
    }

    public function ba(){

        return $this->hasOne(User::class,'id','ba_id');
    } 

    

    public function spoc(){

        return $this->hasOne(User::class,'id','SPOC_id');
    } 

    public function industry()
    {
    return $this->hasOne(IndustryDetail::class,'id','industry_id');
    } 


    public function getCustomerTypes()
    {

    return $this->customer_Type;
    }

    /**
    * 
    */
    public function proposedSystem(){

    return $this->proposed_system;
    }

    public function getSetups(){
        return $this->setups;
    }

    public function getUsage(){
        return $this->usage;
    }




}