<?php

namespace Config;

use CodeIgniter\Config\BaseService;

use App\Models\ProductDetail;
use App\Repositories\CustomerDetailRepository;

use App\Models\CustomerDetail;
use App\Models\CRMDetails;

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Events\Dispatcher;
use Illuminate\Container\Container;


/**
 * Services Configuration file.
 *
 * Services are simply other classes/libraries that the system uses
 * to do its job. This is used by CodeIgniter to allow the core of the
 * framework to be swapped out easily without affecting the usage within
 * the rest of your application.
 *
 * This file holds any application-specific services, or service overrides
 * that you might need. An example has been included with the general
 * method format you should use for your service methods. For more examples,
 * see the core Services file at system/Config/Services.php.
 */
class Services extends BaseService
{

    
    /**
     * 
     */
      public static function ProductDetail($getShared = true)
      {
          if ($getShared) {
              return static::getSharedInstance('ProductDetail');
          }
     
          return new ProductDetail();
      }

      /**
       * 
       */
      public static function CustomerDetail($getShared = true)
      {
          if ($getShared) {
              return static::getSharedInstance('CustomerDetail');
          }
     
          return new CustomerDetail();
      }


          /**
       * 
       */
      public static function CRMDetails($getShared = true)
      {
          if ($getShared) {
              return static::getSharedInstance('CRMDetails');
          }
     
          return new CRMDetails();
      }


    /**
    * 
    */
      public static function CustomerDetailRepository($getShared = true)
      {
          if ($getShared) {
              return static::getSharedInstance('CustomerDetailRepository');
          }
     
          return new App\Repositories\CustomerDetailRepository();
      }



      public static function eloquent()
      {
          $capsule = new Capsule;
      
          $capsule->addConnection([
              'driver'    => 'mysql',
              'host'      => '172.16.12.77',
              'database'  => 'dashBoard',
              'username'  => 'dashboard',
              'password'  => 'dashboard',
              'charset'   => 'utf8mb4',
              'collation' => 'utf8mb4_unicode_ci',
              'prefix'    => '',
          ]);
      
          $capsule->setEventDispatcher(new Dispatcher(new Container));
          $capsule->setAsGlobal();
          $capsule->bootEloquent();
      
          return $capsule;
      }
    //   services('eloquent');    
}
