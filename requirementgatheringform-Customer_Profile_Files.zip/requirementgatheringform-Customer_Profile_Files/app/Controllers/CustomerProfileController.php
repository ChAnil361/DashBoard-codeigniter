<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\CustomerService;
use App\Services\CrmDetailsService;

use CodeIgniter\HTTP\Request;


class CustomerProfileController extends BaseController
{
    /**
     * 
     */

    function __construct(CustomerService $customerService = null,CrmDetailsService $crmservice=null)
    {
        $this->service = $customerService ?? new \App\Services\CustomerService();
        $this->crmservice=$crmservice ?? new \App\Services\CrmDetailsService();
        $this->productService=new \App\Services\ProductDetailsService();
    }


    public function index()
    {

        $product_details = $this->productService->getProductDetails();
        $industry_details = $this->service->getIndustrialDetails();
        $data = $this->service->getOtherFileds();
        

        // $data['CrmDetails_NEW']=json_encode($this->crmservice->getCrmDetails());
        $data['CrmDetails_NEW']=json_encode($this->crmservice->getNewCrmDetails());

        $data['CrmDetails']=json_encode($this->service->getExistCrmNos());
        
        // print_r($this->crmservice->getCrmDetails());
        $data['product_details'] = $product_details;
        $data['industry_details'] = $industry_details;
        $users=$this->service->getAllUsersNames();
        // print_r($users);
        $data['users']=$users;
        // echo "<pre>".print_r($data,1)."</pre>";
 
        return view('customerProfile.php', $data);
    }

    /**
     * 
     */
    function create()
    {

        $request = \Config\Services::request();
         $data=$request->getPost();

         $id=$this->service->create($data);
       echo "stored sucessfully ...! $id";
    }


    /**
     * 
     */
    public function ExistCustomer(int $id)
    {
        $userProfile=$this->crmservice->getCustomerProfile($id);
        // echo $userProfile->exists;
        $data = $this->service->getOtherFileds();
        $data['CrmDetails']=json_encode($this->crmservice->getCrmDetails());
        $data['useProfile']=$userProfile;
        $data['isExistCustomer']=1;
      
        return view('customerProfile.php',$data);
        // echo "<pre>".print_r($userProfile,1)."</pre>";

    }

    /**
     * 
     */
    public function store(Request $request)
    {
        print_r($_POST);
        dd($request);
    }
}
