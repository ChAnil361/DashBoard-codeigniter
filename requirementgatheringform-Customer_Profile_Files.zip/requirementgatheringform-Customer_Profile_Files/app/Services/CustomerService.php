<?php

namespace App\Services;

use App\Services\BaseService;
use App\Services\ProductDetailsService;
use App\Repositories\CustomerDetailRepository;
use App\Repositories\CrmDetailsRepository;
use PDO;

class CustomerService extends BaseService
{

    protected $repository;

    public function __construct(CustomerDetailRepository $customerDetailsRepository = null,
                                CrmDetailsRepository $crmRepository=null,
                                ProductDetailsService $productDetailsService=null)
    {
 
        $this->repository = $customerDetailsRepository ?? new  CustomerDetailRepository;
        $this->crmRepository=$crmRepository ?? new CrmDetailsRepository();
        $this->productDetailsService=$productDetailsService ?? new ProductDetailsService();

    }   

    public function create(array $data): int
    {
   
    //   print_r($data);
    //   exit;
    //   Array ( [customer_type] => 0 [acc_no] => [customer_name] => [spoc_name] => 
    //   [ba_name] => [spoc_phno] => [ba_phno] => [spoc_mail] => [lastName] => 
    //   [ba_mail] => [industry] => 0 [proposed_sys] => 0 [setup] => 0
    //    [product_type] => 0 [product_version] => 0 [usage] => 0 [firstName] => )

        $profile =new \App\Models\CustomerDetail();
        
        $profile->CRM_Account_Number = $data['acc_no']??'1';
        $profile->CRM_Account_name = $data['customer_name']??'Test';
        
           
        // $pid=$this->getProductId(['name'=>$data[''],'version'=>$data['']]);


        $profile->Product_id = $data['product_version']??1;

        $profile->industry_id = $data['industry']??1;
        $profile->Hosting_Type = $data['setup']??1;

        $profile->dialingType = $data['proposed_sys']??1;
        $profile->Pusages = $data['usage']??"test";




        $profile->ba_id = 10;
        $profile->SPOC_id = 11;



        // print_r($profile);
        // dd();
        // $this->repository->getQuery($profile);
        return $this->repository->create($profile);
    }

    public function getCustomerData()
    {

        echo $this->repository->getCustomerDetails();
    }

    public function getProductDetails()
    {
        return $this->repository->getProductDetails();
    }


    public function getIndustrialDetails()
    {
        return $this->repository->getIndustrialDetails();
    }

    /**
     * 
     */
    function getOtherFileds()
    {
        $customer_Type = $this->repository->getCusterTypes();
        $proposed_system = $this->repository->getProposedSystem();
        $setup = $this->repository->getSetups();
        $usages = $this->repository->getUsage();

        return ["customer_Type" => $customer_Type, "proposed_system" => $proposed_system, "setups" => $setup, "usage" => $usages];
    }


    /**
     * 
     */
    function getCrmDetails(){


        //  $this->repository

    }

    public function isExistProduct($data=[])
    {
 
        return $this->productDetailsService->isExist($data);
        # code...
    }



    public function getProductId($data)
    {    
        if(is_object($data)){
            $name=$data->name;
            $version=$data->version;
        }else{
            $name=$data['name'];
            $version=$data['version'];
        }
        $condition=["name"=>$name,"version"=>$version];

        $pid=$this->productDetailsService->getProductID($condition);

        return $pid ?? 0;
    }


   public function getAllUsersNames($id=null)
   {
    $data=[]; 

    // return 
    $query=\App\Models\User::select(['user_name','id',"email","phone"]);
    
    if($id !=null)
         $users=$query->find($id);
    else
         $users=$query->get();
 
    foreach($users as $id=>$values){
        $data['names'][$values->id]=$values->user_name;
        $data['data'][$values->id]=["name"=>$values->user_name,"id"=>$values->id,"email"=>$values->email,"phone"=>$values->phone];
        }
    
        return $data;
} 


   public function pluck($query,string $column, ?string $key = null): array
    {
        $results = [];
        foreach ($query->getResult() as $row) {
            if (!is_null($key)) {
                $results[$row->{$key}] = [$row->{$column}];
            } else {
                $results[] = $row->{$column};
            }
        }
        return $results;

    }

    


    public function getCustomerProfile(int $id)
    {
        return $this->repository->find($id);
    }



    public function getExistCrmNos(){

        $data=$this->repository->getExistCrmNos();
        
        return $data;
    }
}