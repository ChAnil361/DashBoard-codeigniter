<?php

namespace App\Services;

use App\Services\BaseService;
use App\Repositories\ProductDeatailsRepository;

class ProductDetailsService extends BaseService
{
    protected $repository;


    public function __construct(ProductDeatailsRepository $customerDetailsRepository = null)
    {

        $this->repository = $customerDetailsRepository ?? new  ProductDeatailsRepository();
    }

    

    public function getProductDetails(){
        return $this->repository->getProductDetails();
    }

    public function search(array $params)
    {
        // Add custom search functionality
    }



    /**
     * 
     */
    public function isExist(array $condition)
    {

        return  $this->repository->exists($condition);
    }


    public function createProduct($data)
    {

        return $this->repository->create($data);
    }


    public function getProductID(array $data = [])
    {
        return $this->repository->getId($data);
    }
}
