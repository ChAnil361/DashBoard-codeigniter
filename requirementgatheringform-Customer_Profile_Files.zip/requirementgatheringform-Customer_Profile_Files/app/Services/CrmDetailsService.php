<?php

namespace App\Services;

use App\Services\BaseService;

use App\Repositories\CrmDetailsRepository;


class CrmDetailsService extends BaseService
{

    protected $repository;

    public function __construct(CrmDetailsRepository $crmDetailsRepository = null)
    {

        $this->repository = $crmDetailsRepository ?? new  CrmDetailsRepository();
    }
    

    public function getNewCrmDetails()
    {
        $newCrmData=$this->repository->getNewCrmDetails();
        $data=[];

        foreach($newCrmData as $key=>$val){
            $data[$val->crm_no]=["id"=>$val->id,"Acct_no"=>$val->crm_no,"name"=>$val->crm_name]; 
            $data["AcctNos"][]=$val->crm_no;
        }

        return $data;
    }


    function getCrmDetails()
    {   
       return $this->repository->getCrmDetails();
    }

    /**
     * 
     */
    public function getCustomerProfile(int $id){
 
        $userProfile=$this->repository->getProfile($id);
        return $userProfile;
        //    echo "ok=> $id";
    }

    
}