<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;

use App\Repositories\Interfaces\ICustomerDetails;
use App\Models\ProductDetail;
use App\Models\CustomerDetail;
use App\Models\IndustryDetail;
use App\Models\CRMDetail;
// use PDO;

class CustomerDetailRepository extends BaseRepository implements ICustomerDetails
{

    protected $model;

    public function __construct(CustomerDetail $model = null)
    {

        $this->model = $model ?? new CustomerDetail;
        // parent::__construct($this->model);
    }

    /**
     * 
     */
    public function getExistCrmNos()
    {
        $crmAccnos=$this->model::with('crmDetails')->get();
        $data=[];
        foreach($crmAccnos as $key=>$customer){
            $data[$customer->id]=$customer->crmDetails->crm_no;
        }

        return $data;
    }


    public function getCustomerDetails()
    {
        //  var_dump( $this->model->findAll(1));
        return "this getCustomerDetails in Repository..!";
    }

    /**
     *  
     * */
    function getProductDetails()
    {
        $product_model = new ProductDetail();
        return $product_model->where('parent_id')->findAll();

    }

    /**
     * 
     */
    function getIndustrialDetails()
    { 
        $industrials=IndustryDetail::get();
        return IndustryDetail::get();
    }

    

   

    function getCusterTypes()
    {
        $customer_types=$this->model->getCustomerTypes(); 

        return $customer_types;
    }

    function getProposedSystem()
    {
        return $this->model->proposedSystem();
    }

    function getSetups()
    {
        return  $this->model->getSetups();
    }

    function getUsage()
    {
        return $this->model->getUsage();
    }
}
