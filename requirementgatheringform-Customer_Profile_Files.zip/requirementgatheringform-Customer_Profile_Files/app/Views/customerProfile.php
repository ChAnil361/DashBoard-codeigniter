<?= $this->extend('Layouts/baseLayout'); 

$this->section('styles'); ?>
.required{
color:red;
}
<?= $this->EndSection();

$this->section('content'); 

if($isExistCustomer??0)
    (@include_once ("Forms/customer_Exist_profile.php")) or die("File Not Found customer_Exist_profile");
else
    (@include_once ("Forms/customer_profile.php")) or die("File Not Found customer_profile");


$this->EndSection();
$this->section('scripts');?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
<script src="<?= base_url(); ?>assets/js/Forms/customer_profile.js"></script>
<?$this->EndSection();?>