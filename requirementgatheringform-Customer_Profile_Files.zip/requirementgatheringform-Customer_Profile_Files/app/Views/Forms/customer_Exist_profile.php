<!-- <body class="container bg-light"> -->
<!-- Start Header form -->
 
<div class="container-fluid bg-light">
  <div class="text-center pt-2 ">
    <a href="<?= $_ENV['Company_URL']; ?>"><img src="<?= base_url(); ?>assets/images/logo.jpg" alt="network-logo" class="rounded-circle" width=80 hieght=80 /></a>
    <h2> Requirement Gathering - ConVox</h2>
  </div>
  <div class="card">
    <div class="card-header text-center h5">
      <legend>Customer Profile<legend>
    </div>
    <div class="card-body">
      <form class="d-block" method='POST' action="<?= route_to('customer.profile'); ?>">
        <div class="row">
          <div class="form-group col-6">
            <label for="customer_type">Customer Typer: <span class="required ">*</span> </label>


            <select class="form-select" name='customer_type' id="customer_type" aria-label="Default select example">
              <option value=0>--Select--</option>
              <? foreach ($customer_Type as $type) {
                echo "<option value='$type'>$type</option>";
              } ?>
            </select>
          </div>

          <div class="form-group col-6">
            <label for="acc_no">Account Number:</label>
            <span id="AcctNoSpan"><input type="text" class="form-control" id="acc_no" name="acc_no"></span>
          </div>
          <div class="form-group col-6">
            <label for="customer_name">Customer Name</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_name">SPOC Name:</label>
            <!-- <input type="text" class="form-control" id="spoc_name" name="spoc_name"> -->
            <select class="form-select" aria-label="Default select example" id="spoc_name" name="spoc_name">
              <option value=0>--Select--</option>

              <?
              foreach ($users['names'] as $id => $name) {
                echo "<option value=$id>$name</option>";
              }
              ?>
            </select>
          </div>
          <div class="form-group col-6">
            <label for="ba_name">BA Name:</label>
            <!-- <input type="text" class="form-control" id="ba_name" name="ba_name"> -->
            <select class="form-select" aria-label="Default select example" id="ba_name" name="ba_name">
              <option value=0>--Select--</option>

              <?
              foreach ($users['names'] as $id => $name) {
                echo "<option value=$id>$name</option>";
              }
              ?>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_phno">SPOC Contact Number:</label>
            <input type="text" class="form-control" id="spoc_phno" name="spoc_phno">
          </div>
          <div class="form-group col-6">
            <label for="ba_phno">BA Contact Number:</label>
            <input type="text" class="form-control" id="ba_phno" name="ba_phno">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_mail">SPOC Email ID:</label>
            <input type="text" class="form-control" id="spoc_mail" name="spoc_mail">
          </div>
          <div class="form-group col-6">
            <label for="ba_mail">BA Email ID:</label>
            <input type="text" class="form-control" id="ba_mail" name="ba_mail">
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="industry">Process Related To(Industry) :</label>
            <!-- <input type="text" class="form-control" id="lastName" name="lastName"> -->
            <select class="form-select" aria-label="Default select example" id="industry" name="industry">
              <option value=0>--Select--</option>
              <?
              foreach ($industry_details as $key => $industry) {
                echo "<option value=$industry->id>$industry->name-$industry->type</option>";
              }
              ?>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="proposed_sys">Proposed System:</label>

            <select class="form-select" aria-label="Default select example" name="proposed_sys" id="proposed_sys">
              <option value="0">--Select--</option>
              <? foreach ($proposed_system as $key => $proposed) {
                echo "<option value=" . ($key + 1) . ">$proposed</option>";
              } ?>
            </select>
          </div>
          <div class="form-group col-6">


            <label for="setup">Set Up:</label>

            <select class="form-select" aria-label="Default select example" id="setup" name="setup">
              <option value=0>--Select--</option>
              <? foreach ($setups as $key => $setup) {
                echo "<option value=" . ($key + 1) . ">$setup</option>";
              } ?>
            </select>

          </div>
        </div>


        <div class="row">
          <div class="form-group col-6">
            <label for="product_type">Product Type:</label>
            <select class="form-select" aria-label="Default select example" id="product_type" name="product_type">
              <option value="0">--Select--</option>
              <? foreach ($product_details['productName'] as $key => $name) {
                echo "<option value='$key'>$name</option>";
              } ?>
            </select>
          </div>

          <div class="form-group col-6">
            <label for="product_version">Product Version:</label>
            <select class="form-select" aria-label="Default select example" id="product_version" name="product_version">
              <option value=''>--Select--</option>
              <? foreach ($product_details['productVersions'][''] as $key => $version) {
                echo "<option value=$key>$version</option>";
              } ?>
            </select>

          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="usage">Usage:</label>
            <input type="text" class="form-control" id="usage" name="usage" value="<?=$useProfile->customer->Pusages;?>">
            </select>
          </div>
          <div class="form-group col-6">
            <label for="firstName">Sale Manager:</label>
            <input type="text" class="form-control" id="firstName" name="firstName">
          </div>
        </div>
        <div class="row text-center">
          <div class="col p-3">
            <button type="submit" class="btn btn-success m-2">Next</button>
            <button type="button" class="btn btn-danger">Cancel</button>

          </div>
        </div>
      </form>
    </div>

  </div>


</div>
<script>
    var CrmDetails=JSON.parse(`<?=$CrmDetails;?>`);
</script>

<script src="<?= base_url(); ?>assets/js/Forms/customer_Exist_profile.js"></script>
