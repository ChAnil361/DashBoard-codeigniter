
<div class="card">
    <div class="card-header text-center">Product BackLog table <span class="btn btn-warning btn-small float-right pt-0"><i class="icon-plus icon-small" onclick=location.href="<?=base_url("customer/$customer_id/add-product-backlog") ?>">ADD</i></span></div>
    <div class="card-body">
        <table id="productBackLog_Table" class='table table-bordered table-striped  table-hover'>
            <thead>
                <tr>
                    <th>#</th>
                    <th>SNO</th>
                    <th>Module</th>
                    <th>Sub Module</th>
                    <th>Task Name</th>
                    <th>Task Description</th>
                    <th>Man Hours</th>
                    <th>Owner</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                
            </tbody>
                <tr>
                    <td></td>
                    <th></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th></th>
                </tr>
        </table>
    </div>
</div>


<script>
    $(document).ready(function () {
        customer="<?=$customer_id;?>";
        $('#productBackLog_Table').DataTable({
            dom: 'lrtipP',
            "processing": true,
            "serverSide": true,
            pageLength: 5,
            "lengthMenu": [5, 10, 20, 50, 100, 1000],
            "ajax": {
                url:`/DashBoard/customer/DataTable/product-backLog?Customer_id=${customer}`,
                type:"get",
            },
            
            columnDefs: [
                {target: [0, 1],searchable: false },
            ],
            columns: [{
                    data: 'id',
                    orderable: false
                },
                {
                    data: 'sno',
                    orderable: false
                },
                {
                    data: 'Module'
                },
                {
                    data: 'Sub Module'
                },
                {
                    data: 'task_name'
                }
                ,
                {
                    data: 'task_description'
                },
                {
                    data: 'man_hours'
                },
                {
                    data: 'owner'
                },
                {
                    data: 'action',
                    orderable: false
                },
            ],
            initComplete: function (settings, json) {

                var indexColumn = 0;
                search_column=[2,3,4,5,6,7,8,9];
                this.api().columns(search_column).every(function () {
                    
                    
                    var column = this;
                    var input = document.createElement("input");

                    $(input).attr('placeholder', 'Search')
                        .addClass('form-control form-control-sm')
                        .appendTo($('.filterhead:eq(' + indexColumn + ')').empty())
                        .on('keyup', function () {
                            column.search($(this).val(), false, false, true).draw();
                        });

                    indexColumn++;
                });
            }


        });
    });
</script>