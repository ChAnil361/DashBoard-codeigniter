<?= $this->extend('Layouts/baseLayout'); 

$this->section('styles'); ?>
.required{
color:red;
}
<?= $this->EndSection();

$this->section('content'); 

if($isExistCustomer??0)
    (@include_once ("Forms/customer_Exist_profile.php")) or die("File Not Found customer_Exist_profile");
else
    (@include_once ("Forms/customer_profile.php")) or die("File Not Found customer_profile");


$this->EndSection();
$this->section('scripts');?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script src="https://code.jquery.com/ui/1.10.2/jquery-ui.min.js"></script>

<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script> -->

<?$this->EndSection();?>