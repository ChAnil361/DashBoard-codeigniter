<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!-- Bootstrap CSS -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script> -->
    <title><?=$title??'DashBoard';?></title>
    <style>
        <?=$this->renderSection('styles');
        ?>
    </style> 

    <link rel="stylesheet" href="<?=base_url('assets/css/boostrap4/bootstrap.min.css');?>" />
    <link href="<?=base_url('assets/css/boostrap5/bootstrap.min.css');?>" rel="stylesheet">
    <script src="<?=base_url('assets/js/jquery/jquery-3.4.1.slim.min.js');?>"></script>
    <script src="<?=base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?=base_url('assets/js/bootstrap5/bootstrap.min.js');?>"></script>

    <link href="<?=base_url('assets/css/select2.min.css');?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?=base_url('assets/css/dataTables/bootstrap4.min.css');?>" />
    <link href="<?=base_url('assets/css/jquery-ui.min.css');?>" rel="stylesheet" />

    
    <link href="<?=base_url('assets/css/bootstrap-combined.no-icons.min.css');?>" rel="stylesheet" />
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <!-- <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script> -->


    <!-- JavaScript -->
    <script src="<?=base_url('assets/js/alertify.min.js');?>"></script>
    <!-- CSS -->
    <link rel="stylesheet" href="<?=base_url('assets/css/alertify.min.css');?>" />
    <!-- Default theme -->
    <?= $this->renderSection('dependencies')?>


</head>

<body>


    <div class="container"> 
        <?= $this->renderSection('message') ?>
    </div>

    <div class="container-fluid">
        <?= $this->renderSection('content') ?>
    </div>

    <footer>
        <div class="my-4 text-muted text-center">
            <p> © Copyright <?=date("Y");?> <a href="<?=$_ENV['Company_URL'];?>"
                    class="text-decoration-none">Deepijatelecome pvt Ltd.</a> | All Rights Reserved.</p>

        </div>
        <?=$this->renderSection('scripts');?>

        <script>
            $(document).ready(function () {

                <?
                if (session()->getFlashdata('message')){
                    
                    $alert = explode("|",session()->getFlashdata('message'));
                    //  $alert[1]=$alert[1]??'sucess';
                    ?>
                    /*
                     * @message  {String or DOMElement} The notification message contents.
                     * @type     {String }              The Type of notification message (CSS class name 'ajs-{type}' to be added).
                     * @wait     {Number}               The time (in seconds) to wait before the notification is auto-dismissed.
                     * @callback {Function}             A callback function to be invoked when the notification is dismissed.
                     * 
                     * @return {Object} Notification object.
                     *
                     * alertify.notify(message, type, wait, callback)
                     *
                     */

                    alertify.set('notifier', 'position', 'top-right');
                    alertify.notify("<?=$alert[1];?>" , "<?=$alert[0];?>" , 8);
                    
                <?}?>
            });
        </script>
    </footer>
</body>

</html>