<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>

<section class="pt-4">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-lg-9 col-xl-7">
                <div class="card shadow-lg mb-5 bg-white rounded" style="border-radius: 16px;border-top: 5px solid #7de5325e;border-style:solid dashed dashed">
                    <div class="card-body pb-2 p-md-3">
                        <h3 class="pb-2 text-center"><?=$Form_heading;?></h3>
                        <form method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden"  name="Customer_id" value="<?=old('Customer_id',$Customer_id??'');?>">
                            <? 
                            if(session()->has('errors')){
                        echo '<div class="alert alert-danger" role="alert">';
                        foreach (session('errors') as $error){
                            echo "* \t $error"."<br/>";
                            } 
                            echo '</div>';
                            }
                             ?>
                             <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">

                                    <label class="form-label" for="module">Modules:</label>
 
                                    <select name="module" id="module" class="form-select form-control-lg ml-5" name="module">
                                    <option value=''>--Select--</option>
                                    <?
                                    foreach($Module as $id=>$name){
                                         $sel=$id==old('module',$module??'')?"selected":"";
                                    echo "<option value='$id' $sel>$name</option>";
                                    }
                                    ?>
                                    </select>
                                </div>
                        </div>
                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">

                                    <label class="form-label" for="feature">Feature Name:</label>
                                    <select name="feature" id="feature" class="form-select form-control-lg ml-5">
                                    <option value=''>--Select--</option>
                                    <?foreach ($features_data as $key => $value) {
                                           $sel=$value->id==old('feature',$feature??'')?'selected':'';
                                        echo "<option value='$value->id' $sel>$value->name</option>";
                                    }
                                    ?>
                                  </select>

                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="subFeature">Sub Feature</label>
                                    <!-- <input type="text" id="subFeature" class="form-control  form-control-lg  ml-5" name="subFeature" value="<?=old('subFeeature',$subFeeature??'')?>"/> -->
                                    <select name="subFeature" id="subFeature" class="form-select form-control-lg ml-5">
                                    <option value="">-Select--</option>
                                    <?foreach ($subFeature_options??[] as $key => $value) {
                                           $sel=$value['id']==old('subFeature',$subFeature??'')?'selected':'';
                                        echo "<option value='$value[id]' $sel>$value[name]</option>";
                                    }
                                    ?>
                            </select>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Solution_Proposed">Solution Proposed:</label>
                                    <input type="text" id="Solution_Proposed" class="form-control form-control-lg" name="Solution_Proposed" value="<?= old('Solution_Proposed', $Solution_Proposed??'')?>"/>
                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="main_package">Main package</label>
                                    <select id="main_package" class="form-select form-control-lg"  name="main_package" >
                              
                                    <option value="">--Select--</option>
                                    <?
                                    foreach ($main_package as  $value) {
                                        $sel=old('main_package', $main_package_sel??'')==$value?"selected":"";
                                        echo "<option value='$value' $sel>$value</option>";
                                    }
                                    ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label for="BA_id" class="form-label">Owner:</label>
                                    <input type="text" class="form-control  ml-5" id="BA_id" name="BA_id" value="<?= old('BA_id', $BA_id??'')?>" disabled> 
                                </div>
                                <div class="col-md-6 mb-4  d-flex align-items-center">
                                    <label for="Man_Hours" class="form-label">Man Hours:</label>
                                    <input type="text" class="form-control  " id="Man_Hours" name="Man_Hours" value="<?= old('Man_Hours', $Man_Hours??'')?>"> 
                                </div>
                            </div>
                    </div>

                    <div class="pb-3 text-center">
                        <input class="btn btn-danger"
                            onclick=location.href="<?= base_url("customer/$Customer_id/user-story") ?>" type="button"
                            value="Cancel" />
                        <input class="btn btn-success" type="submit" value="Submit" />

                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?$this->EndSection();

$this->section('scripts');?>

<script> 
var subFeature = JSON.parse(`<?=$subFeatures;?>`);
</script>
<script src="<?= base_url(); ?>assets/js/Forms/frd.js"></script>
<?$this->EndSection();
$this->section('dependencies');?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->

<?$this->EndSection();
$this->section('style');?>
<?$this->EndSection()?>