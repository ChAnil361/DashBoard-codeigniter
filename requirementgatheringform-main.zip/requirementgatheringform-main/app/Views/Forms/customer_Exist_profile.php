<!-- <body class="container bg-light"> -->
<!-- Start Header form -->
  
 
<div class="container-fluid bg-light">
  <div class="text-center pt-2 ">
    <a href="<?= $_ENV['Company_URL']; ?>"><img src="<?= base_url(); ?>assets/images/logo.jpg" alt="network-logo" class="rounded-circle" width=80 hieght=80 /></a>
    <h2> Requirement Gathering - ConVox</h2>
  </div>
  <div class="card">
    <div class="card-header text-center h5">
      Customer Profile 
    </div>
    <div class="card-body">
      <form class="d-block" id="Profile_From" method='POST' action="/DashBoard/customer/<?=$customer_id;?>/user-story" >
      <?= csrf_field() ?> 
      <div class="row">
          <div class="form-group col-6">
            <label for="customer_type">Customer Typer: <span class="required ">*</span> </label>


            <select class="form-select" name='customer_type' id="customer_type" aria-label="Default select example">
              <option value=0>--Select--</option>
              <? foreach ($customer_Type as $type) {
                echo "<option value='$type'>$type</option>";
              } ?>
            </select>
          </div>

          <div class="form-group col-6">
            <label for="acc_no">Account Number:</label>
            <span id="AcctNoSpan"><input type="text" class="form-control" id="acc_no" name="acc_no"></span>
          </div>
          <div class="form-group col-6">
            <label for="customer_name">Customer Name</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?=$crm->crm_name;?>">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_name">SPOC Name:</label>
            <input type="text" class="form-control" id="spoc_name" name="spoc_name" value="<?=$spoc->user_name;?>">
          
          </div>
          <div class="form-group col-6">
            <label for="ba_name">BA Name:</label>
            <input type="text" class="form-control" id="ba_name" name="ba_name" value="<?=$ba->user_name;?>">
            
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_phno">SPOC Contact Number:</label>
            <input type="text" class="form-control" id="spoc_phno" name="spoc_phno" value="<?=$spoc->phone;?>">
          </div>
          <div class="form-group col-6">
            <label for="ba_phno">BA Contact Number:</label>
            <input type="text" class="form-control" id="ba_phno" name="ba_phno" value="<?=$ba->phone;?>">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_mail">SPOC Email ID:</label>
            <input type="text" class="form-control" id="spoc_mail" name="spoc_mail" value="<?=$spoc->email;?>">
          </div>
          <div class="form-group col-6">
            <label for="ba_mail">BA Email ID:</label>
            <input type="text" class="form-control" id="ba_mail" name="ba_mail" value="<?=$ba->email;?>">
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="industry">Process Related To(Industry) :</label>
            <input type="text" class="form-control" id="industry" name="industry" value="<?=$industry->name.'-'.$industry->type;?>">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="proposed_sys">Proposed System:</label>
            <input type="text" class="form-control" id="proposed_sys" name="proposed_sys" value="<?=$customer->dialingType;?>">
           
          </div>
          <div class="form-group col-6">


            <label for="setup">Set Up:</label>
            <input type="text" class="form-control" id="setup" name="setup" value="<?=$customer->Hosting_Type;?>">
        
          </div>
        </div>


        <div class="row">
          <div class="form-group col-6">
            <label for="product_type">Product Type:</label>
            <input type="text" class="form-control" id="product_type" name="product_type" value="<?=$product->name;?>">
          </div>

          <div class="form-group col-6">
            <label for="product_version">Product Version:</label>
            <input type="text" class="form-control" id="product_version" name="product_version" value="<?=$product->version;?>">
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="usage">Usage:</label>
            <input type="text" class="form-control" id="usage" name="usage" value="<?=$customer->Pusages;?>">
            </select>
          </div>
          <div class="form-group col-6">
            <label for="sale_manager">Sale Manager:</label>
            <input type="text" class="form-control" id="sale_manager" name="sale_manager">
          </div>
        </div>
        <div class="row text-center">
          <div class="col p-3">
            
            <button type="button" class="btn btn-danger">Cancel</button>
            <button type="submit" class="btn btn-success m-2">Next</button>
          </div>
        </div>
      </form>
    </div>

  </div>


</div>
<script>
    var CrmDetails=JSON.parse(`<?=$CrmDetails;?>`);
    var newAcctNosDetails=JSON.parse(`<?=$CrmDetails_NEW;?>`);
    let existAccount_no="<?=$crm->crm_no;?>";
</script>

<script src="<?= base_url(); ?>assets/js/Forms/customer_Exist_profile.js"></script>
