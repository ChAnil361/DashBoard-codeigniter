<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>

<div class="row pt-1">
    <div class="col">
        <?(@include_once ("Tables/BRD_Table.php")) or die("File Not Found BRD_Table");?>
    </div>
</div>

<div class="row pt-2">
    <div class="col">
        <?(@include_once("Tables/FRD_Table.php")) or die("File Not Found FRD_Table");?>
    </div>
</div>
<div class="row pt-1">
    <div class="col-12 text-center">
    <input type="button" onclick=location.href="<?= base_url("customer/profile/") ?>" class="btn btn-danger" value="Previous"/>     
    <input type="button" onclick=location.href="<?= base_url("customer/$customer_id/product-backlog") ?>"  class="btn btn-success" value="Next"/> 

    </div>

</div>

<?$this->EndSection();


$this->section('scripts');?>
<!-- <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" defer="defer"></script> -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->

<!-- Datatable JS -->
<!-- <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script> -->
<!-- <lin rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css"> -->
    <link rel="stylesheet" type="text/css" href="/DashBoard/assets/css/DataTable/jquery.dataTables.min.css" />
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"> -->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
  
  
  
  <?$this->EndSection();
$this->section('dependencies');?>


    <?$this->EndSection();
$this->section('style');?>
    <?$this->EndSection()?>