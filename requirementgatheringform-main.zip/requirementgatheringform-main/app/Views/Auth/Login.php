<?= $this->extend('Layouts/baseLayout'); 

$this->section('content'); ?> 


<div class="container text-center pt-4   justify-content-center">
    <div class="row">
        <div class="offset-md-2 col-lg-5 col-md-7 offset-lg-4 offset-md-3">
            <div class="panel border bg-white shadow-lg p-3 mb-5 bg-white rounded">
                <div class="panel-heading">
                    <h3 class="font-weight-bold ">Login</h3>
                </div>
                <div class="panel-body p-3"> 
                    <? 
                    if(session()->has('errors')){
                        echo '<div class="alert alert-danger" role="alert">';
                        foreach (session('errors') as $error){
                            echo "* \t $error"."<br/>";
                            } 
                            echo '</div>';
                            }
                             ?>
                    <form class="" action="<?= base_url('Login') ?>" method="post">
                    <?=csrf_field();?>
                        <div class="form-group">
                            <div class="input-field"> <span class="far fa-user font-weight-bold">Email :</span> <input type="text" placeholder="Enter: admin@gamail.com"  id="email" name="email" value="<?=old('email',$email??'');?>" required> </div>
                        </div>
                        <div class="form-group">
                            <div class="input-field"> <span class="fas fa-lock font-weight-bold">Password :</span> <input type="password" name="password" placeholder="Enter your Password : Admin" value="<?=old('password',$password??'');?>" required> </div>
                        </div>
                        <div class="form-inline p-3"> <input type="checkbox" name="remember" id="remember" class="pl-1"> <label for="remember" class="text-muted  pl-2">Remember me</label> <a href="#" id="forgot" class="font-weight-bold">Forgot password?</a> </div>
                        <input type="submit" value="Login" class="btn btn-primary btn-block"/>
                        <!-- <div class="text-center pt-4 text-muted">Don't have an account? <a href="#">Sign up</a> </div> -->
                    </form>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>