<?php
#Author : Anil.c
#Date   : 25-04-23

namespace App\Requests;


use CodeIgniter\Config\Services;
use CodeIgniter\Validation\Exceptions\ValidationException;
use CodeIgniter\Validation\Rules;
use CodeIgniter\Validation\ValidationInterface;

class BaseRequest
{

    public function __construct()
    {
        $this->validator = Services::validation();
        $this->request = \Config\Services::request();
        $this->withRequest();
    }

    public function withRequest()
    {
        $this->data = $this->request->getPost();
        return $this;
    }

    public function setRules(array $rules)
    {
        $this->rules = $rules;
        return $this;
    }

    public function setMessages(array $messages)
    {
        $this->messages = $messages;
        return $this;
    }


    public function getErrors()
    {
        return $this->validator->getErrors();
    }

    public function hasError($field)
    {
        return $this->validator->hasError($field);
    }

    public function getError($field)
    {
        return $this->validator->getError($field);
    }

    public function hasErrors()
    {
        return $this->validator->hasErrors();
    }

    public function getRuleGroup($group)
    {
        return $this->validator->getRuleGroup($group);
    }

    public function setRuleGroup($group, $rules)
    {
        $this->validator->setRuleGroup($group, $rules);
        return $this;
    }

    public function getRule(string $field)
    {
        return $this->validator->getRule($field);
    }

    public function getRules(): array
    {
        return $this->rules;
    }

    public function hasRule(string $field): bool
    {
        return $this->validator->hasRule($field);
    }

    public function reset(): ValidationInterface
    {
        $this->data = [];
        $this->rules = [];
        $this->messages = [];
        $this->validator->reset();

        return $this;
    }

    public function setCallable($rule, $closure)
    {
        $this->validator->setCallable($rule, $closure);
        return $this;
    }

    public function setRulesFromConfig(string $group)
    {
        $this->rules = config('Validation')->getRuleGroup($group);
        return $this;
    }

    public function getRuleGroupNames(): array
    {
        return $this->validator->getRuleGroupNames();
    }

    public function hasDataErrors(array $data, string $group = null): bool
    {
        $validation = Services::validation();
        $validation->setRules($this->rules, $this->messages);

        if ($group !== null) {
            $validation->setRuleGroup($group);
        }

        if (!$validation->run($data)) {
            return true;
        }

        return false;
    }

    public function getDataErrors(): array
    {
        return $this->validator->getErrors();
    }

    public function getErrorsFor($field, string $prefix = '', string $suffix = ''): array
    {
        $messages = $this->validator->getErrors();
        $errors = [];

        foreach ($messages as $name => $message) {
            if ($name == $field) {
                $errors[] = $prefix . $message . $suffix;

            }
        }
        return $errors;
    }
    
    public function getMessages(): array
    {
        return $this->validator->getErrors();
    }
    
    public function setRulesFromModel(string $model)
    {
        $class = model($model);
        $this->rules = $class->validationRules;
        return $this;
    }
    
    public function setRulesFromEntity(string $entity)
    {
        $class = entity($entity);
        $this->rules = $class->getValidationRules();
        return $this;
    }

    /**
     * 
     */
    public function validation(){
        $rules=$this->run();
        $messages=$this->message();
        $this->validator->setRules($rules,$messages);
        // $this->setMessages($messages);
        
		return $this->validator->run($this->data);
    }

    
}