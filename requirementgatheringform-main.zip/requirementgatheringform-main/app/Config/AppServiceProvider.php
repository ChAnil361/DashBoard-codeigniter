<?php namespace Config;

use CodeIgniter\Config\Services;
use CodeIgniter\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register()
    {
        // Register your services here...
        Services::autoloader()->addNamespace('App', APPPATH . 'app');
        
    }

    public function boot()
    {
        // Perform any additional setup here...
    }
}

?>