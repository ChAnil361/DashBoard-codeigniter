<?
namespace  App\Validations;

class CrmRules{
    function checkCrmExist(string $acc_no, string &$error=null, array $data = []): bool
    {
        $is_exis=\App\Models\CRMDetails::where('crm_no',$acc_no)->exists();
        
        return $is_exis??false;
    }

}

?>