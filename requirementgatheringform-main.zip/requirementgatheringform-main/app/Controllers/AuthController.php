<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class AuthController extends BaseController
{
    public function index()
    {
        //
      return  view('Auth/Login');
    }

    /**
     * 
     */
    public function login()
    {
        $validation=new \App\Requests\Auth\LoginRequest();
        $errors=$validation->validation();
        if(!$errors){
            $errors= $validation->getErrors();
            session()->setFlashdata('message', 'error|Validation Failed');
            return redirect()->back()->withInput()->with('errors',$errors);
        }
        $service=new \App\Services\UserService();
        $request=$this->request->getPost();
        $user=$service->findUser($request['email'],$request['password']);
        if(!$user){
            session()->setFlashdata('message', 'error| Invalid Credentials ');
            return redirect()->back()->withInput();
        }

        $this->setUserSession($user);
        session()->setFlashdata('message', 'success| Authorized Succesfully..');
        return redirect()->route('profile');
    }


    /**
     * user information stored in Sessions
     */
    private function setUserSession($user)
    {
        $data = [
            'id' => $user->id,
            'name' => $user->user_name,
            'phone_no' => $user->phone,
            'email' => $user->email,
            'isLoggedIn' => true,
            "is_Admin" => $user->role??1,
        ];

        session()->set($data);
        return true;
    }

    /**
     * 
     */
    public function logout()
    {
        session()->destroy();
        return redirect()->to('login');
    }
}
