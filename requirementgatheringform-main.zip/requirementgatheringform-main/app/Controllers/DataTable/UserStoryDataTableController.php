<?php

namespace App\Controllers\DataTable;

use App\Controllers\BaseController;
use App\Services\CustomerService;
use \Hermawan\DataTables\DataTable;
use \App\Models\CustomerDetail;
use \Config\Services;

class UserStoryDataTableController extends BaseController
{
    public function __construct()
    {
        $this->customerService=new CustomerService();
    }

    public function index()
    {
        //    
    return "This is DataTable Controller ...!";
    }

    public function getData()
    {    

        
    $request = \Config\Services::request()->getGet();
    $customer_id=$request['Customer_id'];

    $sno=0;
    $query =new \App\Models\DataTableModel\BRD();  


    $dataTable = DataTable::of($query);

    $dataTable->postQuery(function($query)use($customer_id){
        $query->where('Customer_id',$customer_id);
        $query->orderBy('id', 'desc');
    });

    $dataTable->add('sno', function($row)use(&$sno){
        return ++$sno;
    },'first');
    
// $dataTable->addNumbering('no');
    $dataTable->add('action', function($row)use($customer_id){
      return $this->getActionBRD($customer_id,$row);
    }, 'last');



  
    return $dataTable->toJson(true);
    }


   public function getFrd_Data(){
        
    $request = \Config\Services::request()->getGet();
    $customer_id=$request['Customer_id'];

    $sno=0;
    $query =new \App\Models\DataTableModel\FRD();

    // $query =new \App\Models\FRD();
    
//     // $feature_details=$query->feature();  
    // $query->where('Customer_id',$customer_id);

    // $feature_details=$query->feature();
    // $query= $query->select('FRD.*,Features.name,users.user_name')->join('Features','Features.id','left')
    // ->join('users','FRD.BA_id=users.id','left')
    // ->where('Customer_id',$customer_id)->get();
//    print_r();

    
        $dataTable = DataTable::of($query);

        $dataTable->postQuery(function($query)use($customer_id){
            $query->where('Customer_id',$customer_id);
            $query->orderBy('id', 'desc');
        });

$dataTable->add('sno', function($row)use(&$sno){
        return ++$sno;
    });


    $dataTable->add('Module Name', function($row){
        return "test";
    });


    $dataTable->add('Module Name', function($row)use($query){
        return $query->module($row->Module_id)->name;
    });
    
    $dataTable->add('Feature Name', function($row)use($query){
        return $query->feature($row->Fid)->name;
    });
     
    $dataTable->add('Sub Feature Name', function($row)use($query){
        return $query->sub_feature($row->subFid)->name;
    });
    

// $dataTable->addNumbering('no');
    $dataTable->add('action', function($row)use($customer_id){
      return $this->getActionFRD($customer_id,$row);
    });

  return $dataTable->toJson(true);
    }

    


    public function getActionBRD($customer_id,$data){
        // print_r($data);
    return "<a href='".base_url("customer/$customer_id/edit-brd/$data->id")."' class=' text-decoration-none'><i class='icon-edit'></i></a><a href='".base_url("customer/$customer_id/delete-brd/$data->id")."' class='link-danger text-decoration-none'>&nbsp;&nbsp;<i class='icon-trash icon-small'></i></a>";
    }

    /**
     * 
     */
    public function getActionFRD($customer_id,$data){
        // print_r($data);
    return "<a href='".base_url("customer/$customer_id/edit-frd/$data->id")."' class=' text-decoration-none'><i class='icon-edit'></i></a><a href='".base_url("customer/$customer_id/delete-frd/$data->id")."' class='link-danger text-decoration-none'>&nbsp;&nbsp;<i class='icon-trash icon-small'></i></a>";
    }


}