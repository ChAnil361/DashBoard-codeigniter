<?php

namespace App\Controllers\DataTable;

use App\Controllers\BaseController;

use \Hermawan\DataTables\DataTable;

class SprintBackLogDataTableController extends BaseController
{
    public function index()
    {
        //
    }

    /**
     * 
     */
    public function getData(){
             
    $request = \Config\Services::request()->getGet();
    $customer_id=$request['Customer_id'];
 
    $sno=0;
    $query =new \App\Models\DataTableModel\SprintBacklog();  

        // dd($query->get())

    return  DataTable::of($query)
            ->add('sno', function($row)use(&$sno){
                return ++$sno;
            })
            
            ->postQuery(function($query)use($customer_id){
                $query->where('Customer_id',$customer_id);
                $query->orderBy('id', 'desc');
            })
           
            ->add('Sub Module', function($row)use($query){
                return $query->sub_module($row->smodule_id)->name;
            }) 
            
            ->add('action',function($row)use($customer_id){
            return $this->getAction($customer_id,$row);
           })


            ->toJson(true);
        
            
    }

    public function getAction($customer_id,$data){
        // print_r($data);
    return "<a href='".base_url("customer/$customer_id/edit-sprint-backlog/$data->id")."' class=' text-decoration-none'><i class='icon-edit'></i></a><a href='".base_url("customer/$customer_id/delete-sprint-backlog/$data->id")."' class='link-danger text-decoration-none'>&nbsp;&nbsp;<i class='icon-trash icon-small'></i></a>";
    }
}
