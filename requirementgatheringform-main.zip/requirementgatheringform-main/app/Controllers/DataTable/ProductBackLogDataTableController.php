<?php

namespace App\Controllers\DataTable;

use App\Controllers\BaseController;

use \Hermawan\DataTables\DataTable;

class ProductBackLogDataTableController extends BaseController
{
    public function index()
    {
        //
    }

    /**
     * 
     */
    public function getData(){
             
    $request = \Config\Services::request()->getGet();
    $customer_id=$request['Customer_id'];
 
    $sno=0;
    $query =new \App\Models\DataTableModel\ProductBacklog();  

    // print_r($query->module(1));
        // dd($query 
     //    $query->join([''])
     

    return  DataTable::of($query)
            ->add('sno', function($row)use(&$sno){
                return ++$sno;
            })
            ->postQuery(function($query)use($customer_id){
                $query->where('Customer_id',$customer_id);
                $query->orderBy('id', 'desc');
            }) 
            ->add('Sub Module', function($row)use($query){
                return $query->sub_module($row->smodule_id)->name;
            }) 
            
            ->add('Module',function($row)use($query){
                return $query->module($row->module_id)->name;
            },'last')


            ->add('action',function($row)use($customer_id){
                return $this->getAction($row,$customer_id);
            })

            ->toJson(true);
        
            
            
    }

    public function getAction($data,$customer_id){
        // print_r($data);
    return "<a href='".base_url("customer/$customer_id/edit-product-backlog/$data->id")."' class=' text-decoration-none'><i class='icon-edit'></i></a><a href='".base_url("customer/$customer_id/delete-product-backlog/$data->id")."' class='link-danger text-decoration-none'>&nbsp;&nbsp;<i class='icon-trash icon-small'></i></a>";
    }
}
