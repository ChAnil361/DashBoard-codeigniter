<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\CustomerService;
use App\Services\CrmDetailsService;

use CodeIgniter\HTTP\Request;
use App\Requests\CustomerProfileRequestRequest;

class CustomerProfileController extends BaseController
{
    /**
     * 
     */

    function __construct(CustomerService $customerService = null,CrmDetailsService $crmservice=null)
    {
        $this->service = $customerService ?? new \App\Services\CustomerService();
        $this->crmservice=$crmservice ?? new \App\Services\CrmDetailsService();
        $this->productService=new \App\Services\ProductDetailsService();
    }


    public function index()
    {

        $data=$this->getDetails();
        
        return view('customerProfile', $data);
    }

    /**
     * 
     */
    function create()
    {
      
        $CustomerProfileRequestRequest=new CustomerProfileRequestRequest();

        $errors=$CustomerProfileRequestRequest->validation();

        $request_data=$this->request->getPost();
       
        if(!$errors){
             $errors= $CustomerProfileRequestRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            } 

                $crm_details=$this->crmservice->getCrmDetails($request_data['acc_no'])->first();
                $data['CRM_Account_Number']=$request_data['acc_no'];
                $data['CRM_Account_name']=$request_data['customer_name'];
                $data['Cmr_id']=$crm_details->id?? 1;
                $data['Product_id']=$request_data['product_type'];
                $data['industry_id']=$request_data['industry'];
                $data['Hosting_Type']=$request_data['proposed_sys'];
                $data['dialingType']=$request_data['setup'];
                $data['Pusages']=$request_data['usage'];
                $data['ba_id']=$request_data['ba_name'];
                $data['SPOC_id']=$request_data['spoc_name'];
                
             $this->service->createCustomerProfile($data);
            $clinet=$this->service->getCustomerID($data);
 
            $success_message = 'success|Your Record has been submitted successfully.';
            session()->setFlashdata('message', $success_message);
            
            return redirect()->route('userstory',[$clinet->id]);
        //  return redirect()->to(base_url("customer/$clinet->id/user-story"));
    }


    /**
     * 
     */
    public function ExistCustomer(int $id)
    {

        $customer=$this->service->findProfileId($id);
        // echo $userProfile->exists;
        $data = $this->service->getOtherFileds(); 
        $data['CrmDetails_NEW']=json_encode($this->crmservice->getNewCrmDetails());
        $data['CrmDetails']=json_encode($this->service->getExistCrmNos());
        

        $data['crm']=$customer->crmDetails;
        $data['customer']=$customer;
        $data['ba']=$customer->ba;
        $data['spoc']=$customer->spoc;
        $data['industry']=$customer->industry;
        $data['product']=$customer->product;
         
        $data['isExistCustomer']=1;
        $data['customer_id']=$id;
        return view('customerProfile',$data);
        // echo "<pre>".print_r($userProfile,1)."</pre>";

    }

    /**
     * 
     */
    public function store(Request $request)
    {
        print_r($_POST);
        dd($request);
    }

    /**
     * 
     */
    public function getDetails()
    {       
        $product_details = $this->productService->getProductDetails();
        $industry_details = $this->service->getIndustrialDetails();
        $data = $this->service->getOtherFileds();        
        $data['CrmDetails_NEW']=json_encode($this->crmservice->getNewCrmDetails());
        $data['CrmDetails']=json_encode($this->service->getExistCrmNos());
        $data['product_details'] = $product_details;
        $data['industry_details'] = $industry_details;
        $users=$this->service->getAllUsersNames();
        $data['users']=$users; 

    return $data;
    }



}