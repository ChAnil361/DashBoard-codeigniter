<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use \App\Requests\Forms\BRDRequest;
use App\Requests\Forms\FRDRequest;

class UserStoryController extends BaseController
{


    function __construct(BRDService $brdService=null){
        $this->brd_service = $brdService ?? new \App\Services\BRDService();
        $this->frd_service = $frdService ?? new \App\Services\FRDService();
        
    }

    public function index($id)
    { 

        // $success_message = 'success|Your form has been submitted successfully.';
        // session()->setFlashdata('message', $success_message);

        $data['customer_id']=$id;
        return View("UserStory",$data);
    }

    public function add($id){
        $data['id']=$id;
        
        return view('Forms/add_brd_Form',$data);
    }

    public function createBrd(int $customer_id)
    {
        // display a form for creating a new user story
        $brdRequest=new BRDRequest();

        $errors=$brdRequest->validation();

       
        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            }
 
            $request_data=$this->request->getPost();
           
            $is_created=$this->brd_service->createBRD($request_data);
            
            
            if(!$is_created){
            session()->setFlashdata('message', 'error|something wen wrong');
            
            return redirect()->back()->withInput()->with('errors',$errors);
            }

            $success_message = 'success|Your Record has been submitted successfully.';
            session()->setFlashdata('message', $success_message);
            
            return redirect()->route('userstory',[$customer_id]);
    }

    public function store(Request $request)
    {
        // process the form submission and store the new user story
    }

    public function show($id)
    {
        
        $data['id']=$id;
        $data['Form_heading']="Add BRD";
        return view('Forms/add_brd_Form',$data);
        // display a single user story based on the given ID
    }

    public function showEditBRD(int $customer_id,int $id){
        
        $brd=$this->brd_service->getBrd($id);

        $data=[
                'id'=>$id,
                'Process'=>$brd->Process,
                'Related_Questions'=>$brd->Related_Questions,
                'Notes'=>$brd->Notes,
                'Why_It_required'=>$brd->Why_It_required,
                'Usage'=>$brd->Usage,
                'User_Story'=>$brd->User_Story,
                'brd_id'=>$brd->id,
                'Form_heading'=>"Edit BRD",
             ];
 
        return view('Forms/add_brd_Form',$data);
    }
    public function edit($id)
    {
        // display a form for editing a user story based on the given ID
    }


    public function updateBRD(int $customer_id, int $id)
    {

        $brdRequest=new BRDRequest();
        $errors=$brdRequest->validation();

        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');             
            return redirect()->back()->withInput()->with('errors',$errors);
            }

            $request_data=$this->request->getPost();
            $brd=$this->brd_service->getBrd($id);

        $brd->Process=$request_data['Process'];
        $brd->User_Story=$request_data['User_Story'];
        $brd->Related_Questions=$request_data['Related_Questions'];
        $brd->Notes=$request_data['Notes'];
        $brd->Why_It_required=$request_data['Why_It_required'];
        $brd->Usage=$request_data['Usage'];
        $brd->save();

        $success_message = 'success|Your Record has been Updated successfully.';
        session()->setFlashdata('message', $success_message);
        
        return redirect()->route('userstory',[$customer_id]);
    }

    public function update(Request $request, $id)
    {
        // process the form submission and update the user story based on the given ID
    }

    public function destroyBRD(int $customer_id,int $id)
    {
        // delete the user story based on the given ID
        $brd=$this->brd_service->find($id);
        $brd->delete();

        $success_message = 'success|Delete Record Successfully.';
        session()->setFlashdata('message', $success_message);

        return redirect()->route('userstory',[$customer_id]);
    }




    /**
     * 
     */
    public function showFrd(int $id){
        $productBacklogService= new \App\Services\ProductBackLogService;
        $data['id']=$id;
        $data['Customer_id']=$id;
        $data['Form_heading']="Add FRD";
        $data['BA_id']=session()->get('name');
        $data["Module"]=$productBacklogService->getModules();

        $data["features_data"]=\App\Models\Feature::all();
        $data["subFeatures"]=$this->frd_service->subFeatures();
        
        $data['main_package']=\App\Models\FRD::main_package;
        return view('Forms/add_frd_Form',$data);

    }


    

    


    public function createFrd(int $customer_id)
    {
        // display a form for creating a new user story
        $brdRequest=new FRDRequest();

        $errors=$brdRequest->validation();

       
        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            }
 
            $request_data=$this->request->getPost();
           
            $is_created=$this->frd_service->create($request_data);
            
            if(!$is_created){
            session()->setFlashdata('message', 'error|something wen wrong');
            
            return redirect()->back()->withInput()->with('errors',$errors);
            }

            $success_message = 'success|Your Record has been submitted successfully.';
            session()->setFlashdata('message', $success_message);
            
            return redirect()->route('userstory',[$customer_id]);
    }



    /**
     * 
     */
    public function showEditFRD(int $customer_id,int $id)
    {
        $frd=$this->frd_service->findFrd($id);
         
        $sub_features=json_decode($this->frd_service->parentSubFeatures($frd->Module_id),true);
        $data['Form_heading']="Edit FRD";
        $data['Customer_id']=$customer_id;
        $data['feature']=$frd->Fid;
        $data['module']=$frd->Module_id;
        $data['subFeature_options']=$sub_features;
        $data["subFeature"]=$frd->subFid;
        // $frd->subFid=$data['subFid'];
        $data['Solution_Proposed']=$frd->Solution_Proposed; 
        $data['main_package_sel']=$frd->main_package;
        $data['BA_id']=session()->get('name');
        $data['Man_Hours']=$frd->Man_Hours; 

        $productBacklogService= new \App\Services\ProductBackLogService;
        $data["Module"]=$productBacklogService->getModules();

        $data["features_data"]=\App\Models\Feature::all();
        $data["subFeatures"]=$this->frd_service->subFeatures();
        $data['main_package']=\App\Models\FRD::main_package;
         
        return view('Forms/add_frd_Form',$data);
    }





    

    public function updateFRD(int $customer_id, int $id)
    {

        $frdRequest=new FRDRequest();
        $errors=$frdRequest->validation();

        if(!$errors){
             $errors= $frdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');             
            return redirect()->back()->withInput()->with('errors',$errors);
            }

            $request_data=$this->request->getPost();
             
        $is_update=$this->frd_service->updateFrd($id,$request_data);

        if( $is_update){
        $success_message = 'success|Your Record has been Updated successfully.';
        session()->setFlashdata('message', $success_message);  
        }
        
        return redirect()->route('userstory',[$customer_id]);
    }




    public function destroyFRD(int $customer_id,int $id)
    {
        $frd=$this->frd_service->find($id);
        $frd->delete();

        $success_message = 'success|Delete Record Successfully.';
        session()->setFlashdata('message', $success_message);

        return redirect()->route('userstory',[$customer_id]);
    }
}