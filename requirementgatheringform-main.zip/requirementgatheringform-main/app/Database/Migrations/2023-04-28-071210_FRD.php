<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class FRD extends Migration
{  
    
    
    public function up()
    {
    $this->db->ForeignKeyChecks(0);
    $this->forge->addField([
        'id'          => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => true,
            'auto_increment' => true,
        ],
        'Customer_id' => [
            'type' => 'INT',
            'constraint' => 11,
            'unsigned' => true,
        ],
        'Module_id' => [
            'type' => 'INT',
            'constraint' => 11,
            'unsigned' => true,
        ],
        'Fid' => [
            'type' => 'INT',
            'constraint' => 11,
            'unsigned' => true,
        ],
        'subFid' => [
            'type' => 'INT',
            'constraint' => 11,
            'unsigned' => true,
        ],
        'Solution_Proposed' => [
            'type' => 'VARCHAR',
            'constraint' => '250'
        ],
        'main_package'  => [
            'type' => 'enum',
            'constraint' =>['Y','N']
        ],
        'BA_id'  => [
            'type'           => 'INT',
            'constraint'     => 11,
            'unsigned'       => true, 
        ],
        'Man_Hours'  => [
            'type' => 'VARCHAR',
            'constraint' => '100'
        ], 
        'created_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'updated_at' => [
            'type' => 'DATETIME',
            'null' => true, 
        ],
         'deleted_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
    ]);

    $this->forge->addForeignKey('Fid', 'Features', 'id'); 
    $this->forge->addForeignKey('subFid', 'sub_feature', 'id'); 
    $this->forge->addForeignKey('BA_id', 'users', 'id'); 
    $this->forge->addForeignKey('Module_id', 'dashBoardModules', 'id'); 
    

    $this->forge->addKey('id', true);
    $this->forge->createTable('FRD');

    $this->db->query("ALTER TABLE FRD MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    $this->db->ForeignKeyChecks(1);
}

public function down()
{
    //
    $this->forge->dropTable('FRD');
}

}
