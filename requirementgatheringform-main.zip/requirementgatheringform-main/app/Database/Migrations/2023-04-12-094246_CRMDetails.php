<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CRMDetails extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            
            'crm_no' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
            ],
            "crm_name" =>[
                'type' => 'VARCHAR',
                'constraint' => 30
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('crmdetails');
        $this->db->query("ALTER TABLE crmdetails MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
        $this->db->ForeignKeyChecks(1);

    }

    public function down()
    {
        //
        $this->forge->dropTable('crmdetails');
    }
}
