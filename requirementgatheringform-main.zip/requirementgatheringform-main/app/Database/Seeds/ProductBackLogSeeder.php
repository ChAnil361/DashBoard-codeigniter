<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProductBackLogSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'user_story_id' => 1,
                'customer_id' => 1,
                'module_id' => 1,
                'smodule_id' => 1,
                'feature_id' => 1,
                'task_name' => 'Task 1',
                'task_description' => 'Description for Task 1',
                'man_hours' => 8,
                'owner' => 'John Doe'
            ],
            [
                'user_story_id' => 1,
                'customer_id' => 2,
                'module_id' => 2,
                'smodule_id' => 2,
                'feature_id' => 2,
                'task_name' => 'Task 2',
                'task_description' => 'Description for Task 2',
                'man_hours' => 8,
                'owner' => 'Jane Doe'
            ],
            // add more data here
        ];

        $this->db->table('product_back_log')->insertBatch($data);
        
    }
}
