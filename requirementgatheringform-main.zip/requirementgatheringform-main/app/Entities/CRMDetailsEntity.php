<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;
use App\Models\CustomerDetail;


class CRMDetailsEntity extends Entity
{
    protected $datamap = [];
    protected $dates   = ['created_at', 'updated_at', 'deleted_at'];
    protected $casts   = [];

    protected $profile = null;

    // public function getProfile()
    // {
    //     return $this->profile;
    // }

    // public function setProfile(CustomerDetail $profile)
    // {
    //     $this->profile = $profile;
    // }
}
