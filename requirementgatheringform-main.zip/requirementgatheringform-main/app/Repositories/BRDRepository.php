<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;
use App\Models\BRD;

use PDO;

class BRDRepository extends BaseRepository
{

    protected $model;

    public function __construct(BRD $model = null)
    {

        $this->model = $model ?? new BRD();
        
        // parent::__construct($this->model);
        // dd($this->model);
    }

    
    function createBrd(array $data)
    {  
        $brd=new BRD();
        $brd->Process=$data['Process'];
        $brd->Related_Questions=$data['Related_Questions'];
        $brd->Notes=$data['Notes'];
        $brd->Why_It_required=$data['Why_It_required'];
        $brd->Usage=$data['Usage'];
        $brd->User_Story=$data['User_Story'];
        $brd->Customer_id=$data['Customer_id'];
        $brd->CRM_id=$brd->customer->Cmr_id;
        return $brd->save(); 
    }

}