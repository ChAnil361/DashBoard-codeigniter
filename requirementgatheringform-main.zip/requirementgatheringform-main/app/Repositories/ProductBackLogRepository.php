<?php

namespace App\Repositories;

// use App\Repository\IProductDetails;
use App\Repositories\BaseRepository;

use App\Models\ProductBackLog;

class ProductBackLogRepository extends BaseRepository
{

    protected $model;

    
    function __construct(ProductBackLog $model=null){
        $this->model = $model ?? new ProductBackLog;
        // parent::__construct($this->model);
         
    }


    public function createProductBackLog(array $data){

        $productBacklog=$this->model;        
        $productBacklog->customer_id=$data['Customer_id'];
        $productBacklog->user_story_id=1;
        $productBacklog->module_id=$data['module'];
        $productBacklog->smodule_id=$data['sub_module'];
        $productBacklog->feature_id=$data['feature'];
        $productBacklog->task_name=$data['task_name'];
        $productBacklog->task_description=$data['task_description'];
        
        $productBacklog->man_hours=$data['man_hours'];
        $productBacklog->owner=session()->get('id');
        return  $productBacklog->save();
    }

    
    
}
