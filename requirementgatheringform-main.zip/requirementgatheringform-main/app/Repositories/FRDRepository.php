<?php

namespace App\Repositories;

use App\Models\FRD;
use App\Repositories\BaseRepository;
use App\Models\BRD;

use PDO;

class FRDRepository extends BaseRepository
{

    protected $model;

    public function __construct(FRD $model = null)
    {

        $this->model = $model ??new FRD();
        
        // parent::__construct($this->model);
        // dd($this->model);
    }

    
    function createFrd(array $data)
    {    
        $frd=$this->model;
        $frd->Customer_id=$data['Customer_id'];
        $frd->Fid=$data['feature'];
        $frd->Module_id=$data['module'];
        $frd->subFid=$data['subFeature'];
        $frd->Solution_Proposed=$data['Solution_Proposed']; 
        $frd->main_package=$data['main_package'];
        $frd->BA_id=session()->get('id');
        $frd->Man_Hours=$data['Man_Hours']; 
        
        return $frd->save(); 
    }



            function updateFrd(int $id,array $data)
            {
                $frd=$this->model->find($id);
                $frd->Customer_id=$data['Customer_id'];
                $frd->Fid=$data['feature'];
                $frd->Module_id=$data['module'];
                $frd->subFid=$data['subFeature'];
                $frd->Solution_Proposed=$data['Solution_Proposed']; 
                $frd->main_package=$data['main_package'];
                $frd->BA_id=session()->get('id');
                $frd->Man_Hours=$data['Man_Hours']; 
                
                return $frd->save(); 
            }


}