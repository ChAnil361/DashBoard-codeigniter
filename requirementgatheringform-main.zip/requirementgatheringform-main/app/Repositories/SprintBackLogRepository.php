<?php

namespace App\Repositories;

// use App\Repository\IProductDetails;
use App\Repositories\BaseRepository;
 
use App\Models\SprintBackLog;

class SprintBackLogRepository extends BaseRepository
{

    protected $model;

    
    function __construct(SprintBackLog $model=null){
        $this->model = $model ?? new SprintBackLog;
        // parent::__construct($this->model);
         
    }


    public function createSprint(array $data){
 
        $sprint=$this->model;        
        $sprint->customer_id=$data['Customer_id'];
        $sprint->user_story_id=1;
        $sprint->Tab_Name=$data['Tab_Name'];
        $sprint->File_List=$data['File_List'];
        $sprint->Menu_Name=$data['Menu_Name'];
        $sprint->Sub_Menu=$data['Sub_Menu'];
        $sprint->Tables_List=$data['Tables_List'];
        $sprint->product_Backlog_id=$data['product_Backlog_id']??1;

    // dd($sprint);
        //  $sprint->User_Story_Id=1;
        // $sprint->owner=session()->get('id');
        return  $sprint->save();
    }
    
}

