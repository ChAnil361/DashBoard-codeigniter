<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;
use App\Models\CRMDetails;

use PDO;

class CrmDetailsRepository extends BaseRepository
{

    protected $model;

    public function __construct(CRMDetails $model = null)
    {

        $this->model = $model ?? new CRMDetails();
        
        // parent::__construct($this->model);
        // dd($this->model);
    }


    function getCrmDetails(int $acc_no){

        //  $crm_details=$this->model->pluck('crm_name','crm_no');
        $crm_details=$this->model->where('crm_no',$acc_no);
        return $crm_details;
    }


    public function getProfile(int $id=0)
    {
        $results=$this->find($id);
       
        return $results;
    }

    public function getNewCrmDetails()
    {
      $data = CRMDetails::leftJoin('customerDetails', 'crmdetails.id', '=', 'customerDetails.Cmr_id')
        ->whereNull('customerDetails.id')
        ->select('crmdetails.*')
        ->get();
 
         return $data;
    }

}
