$(document).ready(function () {
    var customerType = $("#customer_type");
    
    // var users = {}; // Your users object here

    init();

    /**
     * function use to Reverse Key and Values
     * @param {*} data 
     * @returns Object
     */
    const flip = (data) => Object.fromEntries(
        Object
        .entries(data)
        .map(([key, value]) => [value, key])
    );





    //Functoion handler for Account Numbers

    function populateAccountNos(type, val = '') {
        let options = '';
        if (type != 'New') {
            options = '<select class="form-select" aria-label="Default select example" id="acc_no" name="acc_no">';
            options += "<option vlaue=''>--select--</option>";

            for (key in CrmDetails) {
                options += "<option vlaue=" + key + ">" + CrmDetails[key] + "</option>";
            }
            options += "</select>";

        } else {
            options = '<input type="text" class="form-control" id="acc_no" name="acc_no"autocomplete="off">';

        }

        $("#AcctNoSpan").html(options);
        if (type != "New") {
            $("#acc_no").select2().on("select2:select", handleExistCustomer);
        } 

    }

    
    /**
     * @fun used to 
     * @return null
     */
    function handleExistCustomer(e) {
        existCrmNos = flip(CrmDetails);
        Account_no = e.params.data.id;
        profile_id = existCrmNos[Account_no];
        if (profile_id)
            window.location.href = `${profile_id}`;
            
    }

     

    /**
     * @fun used to 
     * @return null
     */
    function handleNewCustomer() {
            window.location.href = `./`;
    }



    /**
     * 
     */
    function init() {
        // Event handler for customer type change
        customerType.on("change", function () {
            type = customerType.val();
            if(type=="New")
                handleNewCustomer();

        });
        populateAccountNos('Existing'); 
        customerType.val("Existing");
    }

var disabled = ['#customer_name',"#spoc_name","#ba_name","#ba_phno","#spoc_phno","#spoc_mail","#ba_mail",
                "#industry","#proposed_sys","#setup","#product_type","#product_version","#usage","#sale_manager"]; // Replace with your array of IDs
$(disabled.join(',')).prop('disabled', true);
 
$('#acc_no').val(existAccount_no).trigger('change');

});
