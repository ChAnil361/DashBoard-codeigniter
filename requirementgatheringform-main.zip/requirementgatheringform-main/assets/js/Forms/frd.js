$(document).ready(function () {
    let feature = $("#feature");
    let subFeature_id = $("#subFeature");

    /**
     * 
     */
    function populateSubFeature(parent_id) {
         let subsubFeaturedata = subFeature[parent_id];
        options = "";
        $.each(subsubFeaturedata, function (index, value) {
            options += `<option value='${value.id}'>${value.name}</option>`;
        });
        subFeature_id.html(options);
    }


    /**
     * Initialized function
     */
    function init() {
        feature.on("change", function (e) { 
            populateSubFeature(feature.val());
        });

    }


    init();
});
