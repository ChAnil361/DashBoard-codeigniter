<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UserStory extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id'          => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'customer_id' => [
                'type' => 'BIGINT',
            ],
            'feature_id'  => [
                'type' => 'BIGINT',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
             'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addForeignKey('customer_id', 'customer_details', 'id');
        $this->forge->addForeignKey('feature_id', 'features', 'id');
        $this->forge->addKey('id', true);

        $this->forge->createTable('user_story');
        $this->db->query("ALTER TABLE user_story MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        $this->db->ForeignKeyChecks(1);
    }

    public function down()
    {
        //
        $this->forge->dropTable('user_story');
    }
}
