<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ModulesSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Module 1',
                'pid' => 1,
                'fid' => 1,
            ],
            [
                'name' => 'Module 2',
                'pid' => 2,
                'fid' => 2,
            ],
            [
                'name' => 'Module 3',
                'pid' => 3,
                'fid' => 3,
            ]
        ];

        $this->db->table('dashBoardModules')->insertBatch($data);
    }
}
