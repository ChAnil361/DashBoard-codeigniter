<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SubFeatureSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Sub-Feature 1',
                'parent_id' => 1,
                'suggestions_id' => 1
            ],
            [
                'name' => 'Sub-Feature 2',
                'parent_id' => 2,
                'suggestions_id' => 2
            ],
            [
                'name' => 'Sub-Feature 3',
                'parent_id' => 3,
                'suggestions_id' => 3
            ]
        ];

        // Insert the data into the sub_feature table
        $this->db->table('sub_feature')->insertBatch($data);
    }
}
