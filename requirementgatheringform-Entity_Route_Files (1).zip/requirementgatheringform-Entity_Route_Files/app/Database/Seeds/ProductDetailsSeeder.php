<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProductDetailsSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'convox',
                'version' => '1.0',
                'parent_id'=>null
            ],
            [
                'name' => 'Confbride',
                'version' => '1.0',
                'parent_id'=>null
            ],
            [
                'name' => 'convox41',
                'version' => '1.0',
                'parent_id'=>null
            ],
            [
                'name' => 'convox',
                'version' => '2.0',
                'parent_id'=>1
            ],
            [
                'name' => 'convox',
                'version' => '3.2',
                'parent_id'=>1
            ],
            [
                'name' => 'convox',
                'version' => '3.2.4',
                'parent_id'=>1
            ],
            
        ];

        $this->db->table('productDetails')->insertBatch($data);
    }
}
