<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SprintBacklogSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'product_Backlog_id' => 1,
                'User_Story_Id' => 1,
                'customer_id' => 1,
                'Tab_Name' => 'Tab 1',
                'File_List' => 'File 1',
                'Menu_Name' => 'Menu 1',
                'Sub_Menu' => 'Submenu 1',
                'Tables_List' => 'Table 1'
            ],
            [
                'product_Backlog_id' => 2,
                'User_Story_Id' => 2,
                'customer_id' => 2,
                'Tab_Name' => 'Tab 2',
                'File_List' => 'File 2',
                'Menu_Name' => 'Menu 2',
                'Sub_Menu' => 'Submenu 2',
                'Tables_List' => 'Table 2'
            ],
            // Add more data as needed
        ];

        $this->db->table('sprint_backlog')->insertBatch($data);
    }
}
