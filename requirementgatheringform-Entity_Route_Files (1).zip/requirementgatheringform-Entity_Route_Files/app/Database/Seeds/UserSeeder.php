<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        //
        
        $faker = \Faker\Factory::create();
          // Empty the table
          $this->db->table('users')->truncate();

          // Seed the table with random data
          for ($i = 1; $i <= 10; $i++) {
              $data = [
                  'user_name' => $faker->userName,
                  'passwod'  => $faker->password,
              ];
              $this->db->table('users')->insert($data);
          }
    }
}
