<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SuggestionSeeder extends Seeder
{
    public function run()
    {
        //
        $data=[
                 [
                    'name' => 'Suggestion 1',
                    'Fid' => 1,
                ],
                [
                    'name' => 'Suggestion 2',
                    'Fid' => 2,
                ],
                [
                    'name' => 'Suggestion 3',
                    'Fid' => 3,
                ],
                // Add more suggestions here
            
        ];
        $this->db->table('suggestion')->insertBatch($data);
    }
}
