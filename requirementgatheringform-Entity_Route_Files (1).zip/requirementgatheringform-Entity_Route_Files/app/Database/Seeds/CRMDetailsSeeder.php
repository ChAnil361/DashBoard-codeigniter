<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CRMDetailsSeeder extends Seeder
{

    public function run()
    {
        //
        $faker = \Faker\Factory::create();
        // Empty the table
        $this->db->table('crmdetails')->truncate();

        // Seed the table with random data
        for ($i = 1; $i <= 40; $i++) {
            $data = [
                'crm_name' => $faker->userName,
                'crm_no'  => $faker->numberBetween(10000, 50000000),
            ];
            $this->db->table('crmdetails')->insert($data);
        }
     } 
}
