<?php

namespace App\Controllers;
 
class Home extends BaseController
{
 
    /**
    * 
    */
    function __construct()
    {
        
    }


    public function index()
    { 
        return view('Forms/customer_profile');
    }
}

//To create an instance
// $ProductDeatailsRepositoriesEloquent = new ProductDeatailsRepositoriesEloquent();
// $myController = new Home($ProductDeatailsRepositoriesEloquent);