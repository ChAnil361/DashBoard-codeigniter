<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\CustomerService;
use App\Services\CrmDetailsService;

use CodeIgniter\HTTP\Request;


class CustomerProfileController extends BaseController
{
    /**
     * 
     */

    function __construct(CustomerService $customerService = null,CrmDetailsService $crmservice=null)
    {
        $this->service = $customerService ?? new \App\Services\CustomerService();
        $this->crmservice=$crmservice ?? new \App\Services\CrmDetailsService();
        $this->productService=new \App\Services\ProductDetailsService();
    }


    public function index()
    {

        $product_details = $this->productService->getProductDetails();
 
        $industry_details = $this->service->getIndustrialDetails();
        
        $data = $this->service->getOtherFileds();

        $data['CrmDetails']=$this->crmservice->getCrmDetails();

        

        // print_r($this->crmservice->getCrmDetails());
        $data['product_details'] = $product_details;
        $data['industry_details'] = $industry_details;

        return view('customerProfile.php', $data);
    }

    /**
     * 
     */
    function create()
    {

        $request = \Config\Services::request();
         $data=$request->getPost();

         $id=$this->service->create($data);

//  exit;
//         print_r($request);


        // $this->service->createProfile();
        echo "stored sucessfully ...! $id";
    }

    /**
     * 
     */
    public function store(Request $request)
    {
        print_r($_POST);
        dd($request);
    }
}
