<?= $this->extend('Layouts/baseLayout'); 

$this->section('styles'); ?>
.required{
color:red;
}
<?= $this->EndSection();

$this->section('content');

include('Forms/customer_profile.php');

$this->EndSection();
$this->section('scripts');?>
<script src="<?= base_url(); ?>assets/js/customer_profile.js"></script>
<?
$this->EndSection();
?>