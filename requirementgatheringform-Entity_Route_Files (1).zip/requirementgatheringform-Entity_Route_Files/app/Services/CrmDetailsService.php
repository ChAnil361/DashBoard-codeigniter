<?php

namespace App\Services;

use App\Services\BaseService;

use App\Repositories\CrmDetailsRepository;


class CrmDetailsService extends BaseService
{

    protected $repository;

    public function __construct(CrmDetailsRepository $customerDetailsRepository = null)
    {

        $this->repository = $customerDetailsRepository ?? new  CrmDetailsRepository;
    }
    

    function getCrmDetails()
    {
       return $this->repository->pluck('crm_name','crm_no');
    }

}
