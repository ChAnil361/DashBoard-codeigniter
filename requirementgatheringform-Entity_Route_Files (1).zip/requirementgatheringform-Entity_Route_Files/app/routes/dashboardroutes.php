<?php
use App\Controllers\CustomerProfileController;

$routes->group('customer',[
            'namespace' => 'App\Controllers',
            'name' => 'customer.'
            ],

            function ($routes) {
             $routes->match(['get'], 'profile', [CustomerProfileController::class,'index'],['as' => 'profile']);
             $routes->post('profile',[CustomerProfileController::class,'create'],['as' => 'profile']);
            });

// $routes->get('requirement-gathering','CustomerProfileController::index');


?>