<?php


public static function CustomerService($getShared = true)
      {
          if ($getShared) {
              return static::getSharedInstance('CustomerService');
          }
     
          return new CustomerService();
      }


      ?>