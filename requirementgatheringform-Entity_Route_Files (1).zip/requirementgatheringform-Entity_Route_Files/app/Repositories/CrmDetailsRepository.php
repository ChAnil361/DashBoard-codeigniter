<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;
use App\Models\CRMDetails;

use PDO;

class CrmDetailsRepository extends BaseRepository 
{

    protected $model;

    public function __construct(CRMDetails $model = null)
    {

        $this->model = $model ?? service('CRMDetails');
        parent::__construct($this->model);
    }



}