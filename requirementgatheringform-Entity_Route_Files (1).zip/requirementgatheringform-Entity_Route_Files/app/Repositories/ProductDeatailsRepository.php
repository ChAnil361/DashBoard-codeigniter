<?php

namespace App\Repositories;

// use App\Repository\IProductDetails;
use App\Repositories\BaseRepository;

use App\Models\ProductDetail;

class ProductDeatailsRepository extends BaseRepository
{

    protected $model;

    
    function __construct(ProductDetail $model=null){
        $this->model = $model ?? new ProductDetail;
        parent::__construct($this->model);
         
    }

    /**
     * 
     */
    function getProductDetails(){
        $products=$this->model->findAll();
        $data=[];
        foreach ($products as $key => $product) {
                if($product->parent_id==null)
                    $data['productName'][$product->id]=$product->name;
                // else
                    $data['productVersions'][$product->parent_id][$product->id]=$product->version;
        }
    //    echo "<pre>".print_r($data,1)."</pre>";
    
    //Remove dublicate parent product vesions
        $data['productVersions']['']=array_unique($data['productVersions']['']);
   
        return $data;
    }
    
}
