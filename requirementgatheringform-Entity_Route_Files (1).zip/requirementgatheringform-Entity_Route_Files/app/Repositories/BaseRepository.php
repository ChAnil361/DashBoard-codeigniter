<?php

namespace App\Repositories;

use CodeIgniter\Model;
use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Database\Query;
use CodeIgniter\Entity;
use CodeIgniter\Database\ResultSet\ResultInterface;


class BaseRepository  extends \CodeIgniter\Entity
{

    protected $model;

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    // protected function toCollection($records): Collection {
    //     return new Collection(array_map([$this, 'entity'], $records));
    // }

    // protected function entity($record){
    //     return new $this->returnType($record);
    // }

    protected function isObject($var)
    {
        return is_object($var);
    }

    public function find(int $id)
    {
        return $this->model->find($id);
    }


    public function findAll()
    {
        return $this->model->findAll();
    }

    /**
     * 
     */
    public function findBy($column, $value)
    {
        return $this->model->where($column, $value)->get()->getResult();
    }

    /**
     * 
     */
    public function create($data)
    {
        if ($this->isObject($data)) {
            $data = (array) $data;
        }
        return $this->model->insert($data);
    }

    /**
     * 
     */
    public function update($id, $data)
    {
        return $this->model->update($id, $data);
    }

    /**
     * 
     */
    public function delete($id)
    {
        return $this->model->delete($id);
    }

    /**
     * 
     */
    public function first()
    {
        return $this->model->first();
    }


    public function count()
    {
        return $this->model->countAll();
    }

    public function orderBy($column, $direction = 'ASC')
    {
        return $this->model->orderBy($column, $direction)->get()->getResult();
    }

    public function limit($limit, $offset = 0)
    {
        return $this->model->limit($limit, $offset)->get()->getResult();
    }


    public function failOrFail($id)
    {
        $result = $this->model->find($id);
        if (!$result) {
            throw new \RuntimeException("Record not found with ID $id");
        }
        return $result;
    }

    public function getQuery(): BaseBuilder
    {
        return $this->model->builder();
    }
    public function where($column, $value = null)
    {
        if (is_array($column)) {
            $this->model->where($column);
        } else {
            $this->model->where($column, $value);
        }
        return $this;
    }

    public function orWhere($column, $value = null)
    {
        if (is_array($column)) {
            $this->model->orWhere($column);
        } else {
            $this->model->orWhere($column, $value);
        }
        return $this;
    }

    public function withTrashed()
    {
        $this->model = $this->model->withDeleted();
        return $this;
    }

    public function withoutTrashed()
    {
        $this->model = $this->model->where('deleted_at', null);
        return $this;
    }

    public function pluck(string $column, ?string $key = null): array
    {
        $this->model->select($column);

        if (!is_null($key)) {
            $this->model->select($key);
        }

        $query = $this->model->get();

        $results = [];

        foreach ($query->getResult() as $row) {
            if (!is_null($key)) {
                $results[$row->{$key}] = $row->{$column};
            } else {
                $results[] = $row->{$column};
            }
        }

        return $results;
    }


    public function exists(array $where)
    {
        $count = $this->model->where($where)->countAllResults();

        return $count > 0;
    }
    
    /**
     * 
     */

    public function getId(array $where,$id_column_name='id')
    {
        $result = $this->model->select($id_column_name)->where($where)->first();

        return $result ? $result[$id_column_name] : false;
    }

}
