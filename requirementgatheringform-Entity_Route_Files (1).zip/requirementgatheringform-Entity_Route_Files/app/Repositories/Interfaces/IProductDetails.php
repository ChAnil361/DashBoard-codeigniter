<?php

namespace App\Repositories\Interfaces;

interface IProductDetails
{
    
/**
 * 
 */
public function getProductDetails();

}

?>
