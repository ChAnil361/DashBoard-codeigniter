<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;

use App\Repositories\Interfaces\ICustomerDetails;
use App\Models\ProductDetail;
use App\Models\CustomerDetail;
use PDO;

class CustomerDetailRepository extends BaseRepository implements ICustomerDetails
{

    protected $model;

    public function __construct(CustomerDetail $model = null)
    {

        $this->model = $model ?? service('CustomerDetail');
        parent::__construct($this->model);
    }


    public function getCustomerDetails()
    {
        //  var_dump( $this->model->findAll(1));
        return "this getCustomerDetails in Repository..!";
    }

    /**
     *  
     * */
    function getProductDetails()
    {
        $product_model = new ProductDetail();
        return $product_model->where('parent_id')->findAll();

    }

    /**
     * 
     */
    function getIndustrialDetails()
    {

        $IndustryDetailModel    = new \App\Models\IndustryDetail();
        return $IndustryDetailModel->findAll();
    }


    function getCusterTypes()
    {
        return $this->model->customer_Type;
    }

    function getProposedSystem()
    {
        return $this->model->proposed_system;
    }

    function getSetups()
    {
        return  $this->model->setups;
    }

    function getUsage()
    {
        return $this->model->usage;
    }
}
