$(document).ready(function () {
    let module = $("#module");
    let sub_module = $("#sub_module");

    /**
     * 
     */
    function populateSubModule(parent_id) {
        let submoduledata = subModule[parent_id];
        options = "";
        $.each(submoduledata, function (index, value) {
            options += `<option value='${value.id}'>${value.name}</option>`;
        });
        sub_module.html(options);
    }


    /**
     * Initialized function
     */
    function init() {
        module.on("change", function (e) {
            populateSubModule(module.val());
        });

    }


    init();
});
