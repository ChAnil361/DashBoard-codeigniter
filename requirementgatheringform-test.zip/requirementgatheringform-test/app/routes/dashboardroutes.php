<?php
use App\Controllers\CustomerProfileController;
use CodeIgniter\Auth\Auth;

$routes->get('/Login',[\App\Controllers\AuthController::class,'index'],['as'=>'login.show']);
$routes->post('/Login',[\App\Controllers\AuthController::class,'login'],['as'=>'login']);


$routes->group('customer',[
            'namespace' => 'App\Controllers',
            ],
        function ($routes) {
             $routes->match(['get'], 'profile', [CustomerProfileController::class,'index'],['as' => 'profile']);
             
             $routes->match(['get'],'profile/(:num)',[CustomerProfileController::class,'ExistCustomer'],['as' => 'profile.exist']);
             
             $routes->post('profile',[CustomerProfileController::class,'create'],['as' => 'profile']);

$routes->group('(:num)',[
                'namespace' => 'App\Controllers',
                'name' => 'story.'
                ],
        
      function($routes){
             $routes->match(['get','post'],'user-story',[\App\Controllers\UserStoryController::class,'index'],['as'=>'userstory']);  
             
             $routes->get('brd',[\App\Controllers\UserStoryController::class,'show'],['as'=>'brd.show']);
             $routes->post('brd',[\App\Controllers\UserStoryController::class,'createBrd'],['as'=>'brd.add']);
             $routes->get('edit-brd/(:num)',[\App\Controllers\UserStoryController::class,'showEditBRD'],['as'=>'brd.edit']);
             $routes->post('edit-brd/(:num)',[\App\Controllers\UserStoryController::class,'updateBRD'],['as'=>'brd.update']);
             $routes->get('delete-brd/(:num)',[\App\Controllers\UserStoryController::class,'destroyBRD'],['as'=>'brd.delete']);
             
             
             $routes->get('frd',[\App\Controllers\UserStoryController::class,'showFrd'],['as'=>'frd.show']);
             $routes->post('frd',[\App\Controllers\UserStoryController::class,'createfrd'],['as'=>'frd.add']);
             $routes->get('edit-frd/(:num)',[\App\Controllers\UserStoryController::class,'showEditFRD'],['as'=>'frd.edit']);
             $routes->post('edit-frd/(:num)',[\App\Controllers\UserStoryController::class,'updateFRD'],['as'=>'frd.update']);
             $routes->get('delete-frd/(:num)',[\App\Controllers\UserStoryController::class,'destroyFRD'],['as'=>'frd.delete']);
             


          //    $routes->get('product-backlog',[\App\Controllers\ProductBacklogController::class,'index'],['as'=>'product.show']);
          //    $routes->get('sprint-backlog',[\App\Controllers\SprintBacklogController::class,'index'],['as'=>'sprint.show']);
         
             /**
              * 
              */

             $routes->get('product-backlog',[\App\Controllers\ProductBacklogController::class,'index'],['as'=>'productBacklog.show']);
             $routes->get('add-product-backlog',[\App\Controllers\ProductBacklogController::class,'show'],['as'=>'productBacklog.add']); 
             $routes->post('add-product-backlog',[\App\Controllers\ProductBacklogController::class,'create'],['as'=>'productBacklog.add']);
             $routes->get('edit-product-backlog/(:num)',[\App\Controllers\ProductBacklogController::class,'edit'],['as'=>'productBacklog.edit']);
             $routes->post('edit-product-backlog/(:num)',[\App\Controllers\ProductBacklogController::class,'update'],['as'=>'productBacklog.update']);
             $routes->get('delete-product-backlog/(:num)',[\App\Controllers\ProductBacklogController::class,'destroy'],['as'=>'productBacklog.delete']);
           
             

             /**
              * 
              */
              $routes->get('sprint-backlog',[\App\Controllers\SprintBacklogController::class,'index'],['as'=>'sprintBacklog.show']);
              $routes->get('add-sprint-backlog',[\App\Controllers\SprintBacklogController::class,'show'],['as'=>'sprintBacklog.add']);
              $routes->post('add-sprint-backlog',[\App\Controllers\SprintBacklogController::class,'create'],['as'=>'sprintBacklog.add']);
             $routes->get('edit-sprint-backlog/(:num)',[\App\Controllers\SprintBacklogController::class,'edit'],['as'=>'sprintBacklog.edit']);
             $routes->post('edit-sprint-backlog/(:num)',[\App\Controllers\SprintBacklogController::class,'update'],['as'=>'sprintBacklog.update']);
             $routes->get('delete-sprint-backlog/(:num)',[\App\Controllers\SprintBacklogController::class,'destroy'],['as'=>'sprintBacklog.delete']);
             



          });

$routes->group('DataTable',
     [
     'namespace' => 'App\Controllers',
     'name' => 'DataTable.'
     ],
     function($routes)
     {
          $routes->get('BRD',[\App\Controllers\DataTable\UserStoryDataTableController::class,'getData'],['as'=>'getData']);

          $routes->get('FRD',[\App\Controllers\DataTable\UserStoryDataTableController::class,'getFrd_Data'],['as'=>'getFrd_Data']);
        
          $routes->get('product-backLog',[\App\Controllers\DataTable\ProductBackLogDataTableController::class,'getData'],['as'=>'getproductBackLog']);
          $routes->get('sprint-backLog',[\App\Controllers\DataTable\SprintBackLogDataTableController::class,'getData'],['as'=>'getsprintBackLog']);
     
     
     });
            
            });

// $routes->get('requirement-gathering','CustomerProfileController::index');


?>