<?

namespace App\Services;

use App\Services\BaseService;

use App\Repositories\BRDRepository;

class BRDService extends BaseService
{

    protected $repository;

    public function __construct(BRDRepository $brdRepository = null)
    {

        $this->repository = $brdRepository ?? new  BRDRepository();
        parent::__construct(new \App\Models\BRD());
    }


    public function createBRD(array $data)
    { 
        return $this->repository->createBrd($data);
    }

    

    public function getBrd(int $id=0)
    {
        return $this->find($id);
    }

}