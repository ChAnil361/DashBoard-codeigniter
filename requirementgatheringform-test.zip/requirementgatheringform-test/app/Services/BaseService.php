<?php
namespace App\Services;


use CodeIgniter\Model;

class BaseService {

    protected $model;
    // public function __construct(Model $model)
    public function __construct($model) {
        // $this->model = $model;
        $this->model = $model;
    }

    public function all() {
        return $this->model->findAll();
    }

    public function find($id) {
        return $this->model->find($id);
    }

    public function findOrFail($id)
    {
        $result = $this->model->find($id);
        if (!$result) {
            throw new \RuntimeException("Record not found with ID $id");
        }
        return $result;
    }

    public function create(array $data) {
    
        return $this->model->insert($data);
    }

    public function update($id, array $data) {
        return $this->model->update($id, $data);
    }

    public function delete($id) {
        return $this->model->delete($id);
    }

    public function getInsertId(){
        return $this->model->insertID();
    } 
    
}
?>