<?php

namespace App\Services;

use App\Services\BaseService;
use App\Services\ProductDetailsService;
use App\Repositories\CustomerDetailRepository;
use App\Repositories\CrmDetailsRepository;
use PDO;
use App\Models\CustomerDetail;

class CustomerService extends BaseService
{

    protected $repository;

    public function __construct(CustomerDetailRepository $customerDetailsRepository = null,
                                CrmDetailsRepository $crmRepository=null,
                                ProductDetailsService $productDetailsService=null)
    {
 
        $this->repository = $customerDetailsRepository ?? new  CustomerDetailRepository;
        $this->crmRepository=$crmRepository ?? new CrmDetailsRepository();
        $this->productDetailsService=$productDetailsService ?? new ProductDetailsService();
       
        $this->model =new CustomerDetail(); 
    
    }   

    // public function create(array $data): int
    // {
   
    
    // }

    public function createCustomerProfile(array $data){
        $is_create=$this->create($data);
        return $is_create?? false;
    }

    public function getCustomerID(array $data)
    { 
        $query=$this->model->where('Cmr_id',$data['Cmr_id']);
        $query->where('Product_id',$data['Product_id']);
        $query->where('ba_id',$data['ba_id']);
        
        return $query->first();
    }



    public function getCustomerData()
    {

        echo $this->repository->getCustomerDetails();
    }

    public function getProductDetails()
    {
        return $this->repository->getProductDetails();
    }


    public function getIndustrialDetails()
    {
        return $this->repository->getIndustrialDetails();
    }


    public function findProfileId($id){
        return $this->repository->find($id);
    }

    /**
     * 
     */
    function getOtherFileds()
    {
        $customer_Type = $this->repository->getCusterTypes();
        $proposed_system = $this->repository->getProposedSystem();
        $setup = $this->repository->getSetups();
        $usages = $this->repository->getUsage();

        return ["customer_Type" => $customer_Type, "proposed_system" => $proposed_system, "setups" => $setup, "usage" => $usages];
    }


    /**
     * 
     */
    function getCrmDetails(int $acc_no)
    {
        //  $this->repository

    }

    public function isExistProduct($data=[])
    {
 
        return $this->productDetailsService->isExist($data);
        # code...
    }



    public function getProductId($data)
    {    
        if(is_object($data)){
            $name=$data->name;
            $version=$data->version;
        }else{
            $name=$data['name'];
            $version=$data['version'];
        }
        $condition=["name"=>$name,"version"=>$version];

        $pid=$this->productDetailsService->getProductID($condition);

        return $pid ?? 0;
    }



   public function getAllUsersNames($id=null)
   {
    $data=[]; 

    // return 
    $query=\App\Models\User::select(['user_name','id',"email","phone"]);
    
    if($id !=null)
         $users=$query->find($id);
    else
         $users=$query->get();
 
    foreach($users as $id=>$values){
        $data['names'][$values->id]=$values->user_name;
        $data['data'][$values->id]=["name"=>$values->user_name,"id"=>$values->id,"email"=>$values->email,"phone"=>$values->phone];
        }
    
        return $data;
} 




   public function pluck($query,string $column, ?string $key = null): array
    {
        $results = [];
        foreach ($query->getResult() as $row) {
            if (!is_null($key)) {
                $results[$row->{$key}] = [$row->{$column}];
            } else {
                $results[] = $row->{$column};
            }
        }
        return $results;

    }

    


    public function getCustomerProfile(int $id)
    {
        return $this->repository->find($id);
    }



    public function getExistCrmNos(){

        $data=$this->repository->getExistCrmNos();
        
        return $data;
    }

    public function getQuery()
    {
        return \App\Models\CustomerDetail::query();
    }

     
}