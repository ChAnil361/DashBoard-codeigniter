<?
namespace App\Services;

use App\Services\BaseService;
use App\Repositories\UserRepository;

class UserService extends BaseService
{

    protected $repository;

    public function __construct(UserRepository $userRepository = null)
    {

        $this->repository = $userRepository ?? new  UserRepository();
        parent::__construct(new \App\Models\User);
    }
 
    public function findUser(string $email,$password)
    {
        $query=$this->model->where('email',$email)
                ->where('password',$password);
        return $query->first();


    }

}