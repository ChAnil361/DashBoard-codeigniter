<?

namespace App\Services;

use App\Models\SubFeature;
use App\Services\BaseService;

use App\Repositories\BRDRepository;

class FRDService extends BaseService
{

    protected $repository;

    public function __construct(FRDRepository $brdRepository = null)
    {

        $this->repository = $brdRepository ?? new  \App\Repositories\FRDRepository();
        parent::__construct(new \App\Models\FRD);
    }


    public function create(array $data)
    { 
        return $this->repository->createFrd($data);
    }

    public function getFrd(int $id=0)
    {
        return $this->find($id);
    }

    
        /**
         * 
         */
        public function findFrd(int $id){
            return $this->findOrFail($id);
        }


    /**
     * 
     */
    public function subFeatures(int $id=0)
    {
        $data=[];

        if($id){
            $subFeatureData=SubFeature::where('id',$id)->get();
        }else{
            $subFeatureData=SubFeature::all();
        }

        foreach ($subFeatureData as $subFeature) {
            $data[$subFeature->parent_id][]=["id"=>$subFeature->id,"name"=>$subFeature->name];
        }
        
        return json_encode($data); 
    }


    public function parentSubFeatures($id)
    {
        $data=[];

        if($id){
            $subFeatureData=SubFeature::where('parent_id',$id)->get();
        }else{
            $subFeatureData=SubFeature::all();
        }

        foreach ($subFeatureData as $subfeature) {
            $data[]=["id"=>$subfeature->id,"name"=>$subfeature->name];
        }
        
        return json_encode($data); 
    }



    function updateFrd(int $id,array $data)
    {   
        $frd=$this->repository->updateFrd($id,$data);
      
        return $frd;
    }
    


}