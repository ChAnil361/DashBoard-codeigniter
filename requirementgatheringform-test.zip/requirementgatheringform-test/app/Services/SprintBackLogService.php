<?

namespace App\Services;

use App\Repositories\SprintBackLogRepository;
use App\Services\BaseService;

use App\Repositories\sprintRepository;

class SprintBackLogService extends BaseService
{

    protected $repository;

    public function __construct(SprintBackLogRepository $brdRepository = null)
    {
       $this->repository = $brdRepository ?? new  SprintBackLogRepository();
        parent::__construct(new \App\Models\SprintBackLog());
    }


        /**
         * 
         */
        public function findSprint(int $id){
            return $this->findOrFail($id);
        }


        /**
         * 
         */
        public function createSprint($data)
        {

            return $this->repository->createSprint($data);
        }


        /**
         * 
         */
        public function deleteSprint(int $sprint_backlog_id)
        {

            return $this->findSprint($sprint_backlog_id)->delete();
        }



        /**
         * 
         */
        public function updateSprint(int $sprint_id,array $data){

            $sprint=$this->findSprint($sprint_id);

            $sprint->customer_id=$data['Customer_id'];
            $sprint->user_story_id=1;
            // $sprint->module_id=$data['module'];
            $sprint->Tab_Name=$data['Tab_Name'];
            $sprint->Menu_Name=$data['Menu_Name'];
            $sprint->Sub_Menu=$data['Sub_Menu'];
            // $sprint->task_name=$data['Task_Name'];
            $sprint->File_List=$data['File_List'];
            $sprint->Tables_List=$data['Tables_List'];
            // $sprint->man_hours=$data['Man_Hours'];
            // $sprint->owner=session()->get('id');

            return $sprint->save();
        }



}