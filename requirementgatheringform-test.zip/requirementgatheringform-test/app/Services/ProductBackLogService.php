<?

namespace App\Services;

use App\Models\Module;
use App\Models\SubModule;
use App\Services\BaseService;

use App\Repositories\ProductBackLogRepository;

class ProductBackLogService extends BaseService
{

    protected $repository;

    public function __construct(ProductBackLogRepository $brdRepository = null)
    {

        $this->repository = $brdRepository ?? new  ProductBackLogRepository();
        parent::__construct(new \App\Models\ProductBackLog());
    }

    public function getModules(int $id=0)
    {
        if($id){
            return Module::where('id',$id)->pluck('name','id');
        }
        return Module::all()->pluck('name','id');
    }
 

    public function getSubModule(int $id=0)
    {
        $data=[];
        if($id){
            $subModuleData=SubModule::where('id',$id)->get();
        }else{
            $subModuleData=SubModule::all();
        }

        foreach ($subModuleData as $subModule) {
            $data[$subModule->parent_id][]=["id"=>$subModule->id,"name"=>$subModule->name];
        }
        
        return json_encode($data);
    }


    /**
     * 
     */
    public function findParentSubModules(int $id)
    {
        $data=[];
        $subModuleData=SubModule::where('parent_id',$id)->get();
        foreach ($subModuleData as $subModule) {
            $data[$subModule->parent_id][]=["id"=>$subModule->id,"name"=>$subModule->name];
        }
        return $data;
    }
    

        /**
         * 
         */
        public function createProductBackLog($data)
        {

            return $this->repository->createProductBackLog($data);
        }

        /**
         * 
         */
        public function findProductBackLog(int $id){
            return $this->findOrFail($id);
        }

        /**
         * 
         */
        public function updateProductBackLog(int $productid,array $data)
        {   
        

            $productBacklog=$this->findProductBackLog($productid);
            $productBacklog->customer_id=$data['Customer_id'];
            $productBacklog->user_story_id=1;
            $productBacklog->module_id=$data['module'];
            $productBacklog->smodule_id=$data['sub_module'];
            $productBacklog->feature_id=$data['feature'];
            $productBacklog->task_name=$data['task_name'];
            $productBacklog->task_description=$data['task_description'];
            
            $productBacklog->man_hours=$data['man_hours'];
            $productBacklog->owner=session()->get('id');

            return $productBacklog->save();

        }




        public function deleteProductBacklog(int $product_backlog_id)
        {

            return $this->findOrFail($product_backlog_id)->delete();
        }


}