<?php

namespace Config;

use Illuminate\Database\Capsule\Manager as Capsule;

/**
 * 
 */

 class Eloquent
 {
    function __construct()
    {

        $capsule = new Capsule;
        $conf = Config('Database');
        //DBDriver
        $capsule->addconnection(array( 
            'driver'    => $conf->default['DBDriver'],
            'host'      => $conf->default['hostname'],
            'port'      => $conf->default['port'],
            'database'  => $conf->default['database'],
            'username'  =>  $conf->default['username'],
            'password'  =>  $conf->default['password'],
            'charset'   => $conf->default['charset'],
            'collation' => $conf->default['DBCollat'],
            'prefix'    =>  $conf->default['DBPrefix']
        ),'default');
        
        $capsule->setAsGlobal();

        $capsule->bootEloquent();
    }

 }
 