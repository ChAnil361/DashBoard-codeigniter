<?php

namespace App\Requests\Auth;

use App\Requests\BaseRequest;

class LoginRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[
		'email' => 'required|min_length[6]|max_length[50]|valid_email',
		'password' => 'required|min_length[5]|max_length[255]',
	];

	return $rules;
}	

public function  message(){

	return [
		'password' => [
			'validateUser' => "Email or Password didn't match",
		],
	];
}
}