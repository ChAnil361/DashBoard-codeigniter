<?php

namespace App\Requests;

use App\Requests\BaseRequest; 

class CustomerProfileRequestRequest  extends BaseRequest
{

	protected $data = [];
    protected $rules = [];
    protected $messages = [];
	
    public function run()
    {

		$rules=[
			'acc_no' => "required|numeric|checkCrmExist|is_unique[customerDetails.CRM_Account_Number]",

			'customer_name'=>"required|min_length[3]",
			'spoc_name'=>"required",
			"ba_name"=>"required",
			// "spoc_phno"=>"numeric",
			// "ba_phno"=>"numeric",
			"spoc_mail"=>"valid_email",
			"ba_mail"=>"valid_email",
			"industry"=>"required|numeric",
			"proposed_sys"=>"required",
			"setup"=>"required",
			"product_type"=>"numeric",
			"usage"=>"required|min_length[1]",
		];

		return $rules;
    }

 


	/**
	 * 
	 */
	public function  message(){
		// $messages=[];
		return [   
			'acc_no' => ['required'=>"<b>Account Number</b> is Required","numeric"=>"<b>Account Number</b> field must contain only numbers.","checkCrmExist" =>'<b>CRM Account Number</b> not Exist'],
			
			'customer_name'=>["required"=>"<b>Customer Name</b> is Required","min_length"=>"<b>Customer Name</b> Must be 3 characters"],
			
			'spoc_name'=>["required"=>"<b>SPOC Name</b> is Required","min_length"=>"<b>SPOC Name</b> Must be 3 characters"],
			
			"ba_name"=>["required"=>"<b>BA Name</b> is Required","min_length"=>"<b>BA</b> Atleast 3 characters"],
			
			"spoc_phno"=>["numeric"=>"<b>Spoc</b> Phonenumber field must contain only numbers"],
			
			"ba_phno"=>["numeric"=>"<b>BA</b> Phonenumber field must contain only numbers"],

			"spoc_mail"=>["valid_email"=>"<b>Spoc</b> Mail invalid email"],
			
			"ba_mail"=>["valid_email"=>"<b>BA</b> Mail Mail invalid email"],
			
			"industry"=>['required'=>"<b>Indusytry</b> is Required","numeric"=>"<b>Indusytry</b> Must be field must contain only numbers"],
			
			"proposed_sys"=>['required'=>"<b>Proposed System</b> is required","numeric"=>"<b>Proposed System</b> must contain only numberic"],
			
			"setup"=>['required'=>"<b> Setup </b>  is Required","numeric"=>"<b> Setup </b> is numberic"],
			
			"product_type"=>['required'=>"<b> ProductType </b> is required","numeric"=>"<b>ProductType</b> is numeric"],
			
			"usage"=>["required"=>"<b>Usage </b>  is required","alpha_space"=>"<b>Usage</b> is numberic"],
		];
	}
	
}