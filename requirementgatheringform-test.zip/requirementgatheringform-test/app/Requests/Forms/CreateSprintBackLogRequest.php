<?php

namespace App\Requests\Forms;

use App\Requests\BaseRequest;

class CreateSprintBackLogRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[
		
		"Task_Name"=>"required",
		"Tab_Name"=>"required",
		"Menu_Name"=>"required",
		"Sub_Menu"=>"required",
		"File_List"=>"required",
		"Dev_description"=>"required",
		"Man_Hours"=>"required",
	];

	return $rules;
}	

public function  message(){

	return [

	];
}
}