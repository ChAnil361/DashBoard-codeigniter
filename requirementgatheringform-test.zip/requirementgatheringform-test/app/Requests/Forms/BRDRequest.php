<?php

namespace App\Requests\Forms;

use App\Requests\BaseRequest;

class BRDRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[
		// "CRM_id"=>"required",
		"Process"=>"required",
		"Related_Questions"=>"required",
		"Notes"=>"required",
		"Why_It_required"=>"required",
		"User_Story"=>"required",
		"Customer_id"=>"required"
	];

	return $rules;
}	

public function  message(){

	return [

	];
}
}