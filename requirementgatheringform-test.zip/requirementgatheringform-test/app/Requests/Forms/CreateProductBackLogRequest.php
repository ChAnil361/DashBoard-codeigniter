<?php

namespace App\Requests\Forms;

use App\Requests\BaseRequest;

class CreateProductBackLogRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[
		
		"module"=>"required",
		"feature"=>"required",
		// "sub_module"=>"required",
		// "sub_module"=>"required",
		"task_name"=>"required",
		"task_description"=>"required",
		// "owner"=>"required",
		"man_hours"=>"required"
	];

	return $rules;
}	

public function  message(){

	return [

	];
}
}