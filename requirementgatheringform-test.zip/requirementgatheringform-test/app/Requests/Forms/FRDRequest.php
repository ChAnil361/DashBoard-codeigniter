<?php

namespace App\Requests\Forms;

use App\Requests\BaseRequest;

class FRDRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[
		"module"=>"required",
		"feature"=>"required",
		"subFeature"=>"required",
		"Solution_Proposed"=>"required",
		"main_package"=>"required",
		"Customer_id"=>"required",
		// "BA_id"=>"required",
		"Man_Hours"=>"required"

	];

	return $rules;
}	

public function  message(){

	return [
		
	];
}
}