<?php

namespace App\Requests;

use App\Requests\BaseRequest;

class TestRequest extends BaseRequest
{
protected $data = [];

protected $rules = [];

protected $messages = [];

	public function run(){

	$rules=[


	];

	return $rules;
}	

public function  message(){

	return [

	];
}
}