<?php

namespace App\Repositories\Interfaces;

interface ICustomerDetails
{

    /**
     * 
     */
    public function getCustomerDetails();


}