<?php

namespace App\Repositories;

use App\Repositories\BaseRepository;
use App\Models\User;

use PDO;

class UserRepository extends BaseRepository
{

    protected $model;

    public function __construct(User $model = null)
    {

        $this->model = $model ?? new User();
        // parent::__construct($this->model);
        // dd($this->model);
    }
    
}