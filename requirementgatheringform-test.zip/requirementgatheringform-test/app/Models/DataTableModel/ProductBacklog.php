<?php

namespace App\Models\DataTableModel;

use CodeIgniter\Model;

class ProductBacklog extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'product_back_log';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];



    public function module($id){

        return $this->db->table('dashBoardModules')
            ->where('id', $id)
            ->get()
            ->getRow();

        // return $this->belongsTo(Module::class,'module_id','id');
    }

    public function sub_module($id){ 

            return $this->db->table('sub_module')
                ->where('id', $id)
                ->get()
                ->getRow();        
    }


}
