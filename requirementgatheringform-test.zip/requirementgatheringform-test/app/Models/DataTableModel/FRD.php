<?php

namespace App\Models\DataTableModel;

use CodeIgniter\Model;

class FRD extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'FRD';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

 


    public function module($id){

        return $this->db->table('dashBoardModules')
            ->where('id', $id)
            ->get()
            ->getRow();

        // return $this->belongsTo(Module::class,'module_id','id');
    }


    
    public function feature($id){

        return $this->db->table('Features')
            ->where('id', $id)
            ->get()
            ->getRow();

        // return $this->belongsTo(Module::class,'module_id','id');
    }

    public function sub_feature($id){

        return $this->db->table('Features')
            ->where('id', $id)
            ->get()
            ->getRow();

        // return $this->belongsTo(Module::class,'module_id','id');
    }

}
