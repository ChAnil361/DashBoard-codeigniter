<?php
#Author : Anil.c 

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Services;
use CodeIgniter\Files\File;

class MakeRequest extends BaseCommand
{
    protected $group = 'Generators';
    protected $name = 'make:request';
    protected $description = 'Generate a new form request class.';

    protected $arguments = [
        'name' => 'The name of the request class to create.'
    ];

    protected $options = [
        'rules' => 'The Requests rules for the request class, in JSON format.'
    ];

    public function run(array $params)
{
    // Get the name of the request class to create
    $name = array_shift($params);
    if (empty($name)) {
        CLI::error('You must provide a name for the request class.');
        return;
    }

    // Get the Requests rules for the request class (if any)
    $rules = $this->getOptions()['rules'] ?? null;
    if (!empty($rules)) {
        $rules = json_decode($rules, true);
        if (!is_array($rules)) {
            CLI::error('The Requests rules must be in JSON format.');
            return;
        }
    } else {
        $rules = [];
    }

    // Define the namespace and class name for the new request
    $namespace = 'App\Requests';
    
    //#Note create sub sub dir Request Dir
    if(strrpos($name,"/") && substr($name,0,strrpos($name,"/")) ){
        $dir=substr($name,0,strrpos($name,"/"));
        // $is_dir_exist=$this->checkIsDirExist($dir);
        // if($is_dir_exist){
        //     $namespace.=str_replace("/","\\",$dir);
        // }
        $namespace.="\\".str_replace("/","\\",$dir);
        $className=ucfirst(substr($name,strrpos($name,"/")+1)). 'Request';
        // Determine the path to save the new request file
        $path = APPPATH . 'Requests/' . $dir.'/'.$className . '.php';
    }
    else{
        $className = ucfirst($name) . 'Request';  
        // Determine the path to save the new request file
        $path = APPPATH . 'Requests/' . $className . '.php';
    }

    // Create the PHP code for the new request class
    $code = "<?php\n\nnamespace {$namespace};\n\nuse App\Requests\BaseRequest;\n\nclass {$className} extends BaseRequest\n{\n";

    // Add the setRules() method to the code
    $code .= "protected \$data = [];\n\nprotected \$rules = [];\n\nprotected \$messages = [];\n\n";

    $code.="\tpublic function run(){\n\n\t\$rules=[\n\n\n\t];\n\n\treturn \$rules;\n}";

    $code.="\t\n\npublic function  message(){\n\n\treturn [\n\n\t];\n}\n}";



// Check if the file already exists
if (file_exists($path)) {
    CLI::error('The request class already exists.');
    return;
}

// Create the new request file
$handle = fopen($path, 'w');
if (!$handle) {
    CLI::error('Failed to create the request class file.');
    return;
}

fwrite($handle, $code);
fclose($handle);

CLI::write('Request class created: ' . $className);

    
    // ...
}
public function getOptions(){
return null;
}
public function checkIsDirExist($dir){
    if(!is_dir($dir)){ 
    mkdir("App/Requests/$dir", 777, true);
    return 1;
    }else{
        return 0;
    }

    return 0;
}
}
?>