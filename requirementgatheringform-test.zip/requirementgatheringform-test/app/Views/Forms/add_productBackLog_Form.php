<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>

<section class="pt-4">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-lg-9 col-xl-7">
                <div class="card shadow-lg mb-5 bg-white rounded" style="border-radius: 16px;border-top: 5px solid #7de5325e;border-style:solid dashed dashed">
                    <div class="card-body pb-2 p-md-3">
                        <h3 class="pb-2 text-center"><?=$Form_heading;?></h3>
                        <form method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden"  name="Customer_id" value="<?=old('Customer_id',$id??'');?>">
                            <? 
                            if(session()->has('errors')){
                        echo '<div class="alert alert-danger" role="alert">';
                        foreach (session('errors') as $error){
                            echo "* \t $error"."<br/>";
                            } 
                            echo '</div>';
                            }
                             ?>
                             <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">

                                    <label class="form-label" for="module">Modules:</label>
                                    <select name="module" id="module" class="form-select form-control-lg ml-5" name="module">
                                    <option value=''>--Select--</option>
                                    <?
                                    foreach($Module as $id=>$name){
                                         $sel=$id==old('module',$module??'')?"selected":"";
                                    echo "<option value='$id' $sel>$name</option>";
                                    }
                                    
                                    ?>
                                    </select>
                                     
                                </div>
                        </div>
                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                
                                      <label class="form-label" for="feature">Sub Module:</label> 
                            
                            <select name="sub_module" id="sub_module" class="form-select form-control-lg ml-5">
                                    <option value="">-Select--</option>
                                    <?foreach ($subModule_options??[] as $key => $value) {
                                           $sel=$value['id']==old('feature',$sub_module??'')?'selected':'';
                                        echo "<option value='$value[id]' $sel>$value[name]</option>";
                                    }
                                    ?>
                            </select>
                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="feature">Feature Name</label>
                                   <select name="feature" id="feature" class="form-select form-control-lg ml-5">
                                    <option value=''>--Select--</option>
                                    <?foreach ($features_data as $key => $value) {
                                           $sel=$value->id==old('feature',$feature??'')?'selected':'';
                                        echo "<option value='$value->id' $sel>$value->name</option>";
                                    }
                                    ?>
                                  </select>
                                    <!-- <input type="text" id="feature" class="form-control  form-control-lg  ml-5" name="feature" value="<?=old('feature',$feature??'')?>"/> -->
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="task_name">Task Name :</label>
                                    <input type="text" id="task_name" class="form-control form-control-lg" name="task_name" value="<?= old('task_name', $task_name??'')?>"/>
                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="task_description">Task Description</label>
                                  <textarea id="task_description" class="form-control form-control-lg"  name="task_description"><?= old('task_description', $task_description??'')?></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label for="owner" class="form-label">Owner:</label>
                                    <input type="text" class="form-control  ml-5" id="owner" name="owner" value="<?= old('owner',$owner??'')?>" disabled> 
                                </div>
                                <div class="col-md-6 mb-4  d-flex align-items-center">
                                    <label for="man_hours" class="form-label">Man Hours:</label>
                                    <input type="text" class="form-control  " id="man_hours" name="man_hours" value="<?= old('man_hours', $man_hours??'')?>"> 
                                </div>
                            </div>
                    </div>

                    <div class="pb-3 text-center">
                        <input class="btn btn-danger"
                            onclick=location.href="<?= base_url("customer/$id/product-backlog") ?>" type="button"
                            value="Cancel" />
                        <input class="btn btn-success" type="submit" value="Submit" />

                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?$this->EndSection();
$this->section('scripts');?>
<script> 
var subModule = JSON.parse(`<?=$subModule;?>`);
</script>
<script src="<?= base_url(); ?>assets/js/Forms/product_backlog.js"></script>
<?$this->EndSection();

$this->section('dependencies');?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->

<?$this->EndSection();
 