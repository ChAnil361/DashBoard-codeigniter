<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>

<section class="pt-4">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-lg-9 col-xl-7">
                <div class="card shadow-lg mb-5 bg-white rounded" style="border-radius: 16px;border-top: 5px solid #7de5325e;border-style:solid dashed dashed">
                    <div class="card-body pb-2 p-md-3">
                        <h3 class="pb-2 text-center"><?=$Form_heading;?></h3>
                        <form method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden"  name="Customer_id" value="<?=old('Customer_id',$id??'');?>">
                            <? 
                            if(session()->has('errors')){
                        echo '<div class="alert alert-danger" role="alert">';
                        foreach (session('errors') as $error){
                            echo "* \t $error"."<br/>";
                            } 
                            echo '</div>';
                            }
                             ?>
                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">

                                    <label class="form-label" for="Process">Process:</label>
                                    <input type="text" id="Process" class="form-control form-control-lg ml-5" name="Process" value="<?=old('Process',$Process??'')?>"/>

                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="usage">Usage</label>
                                    <input type="text" id="usage" class="form-control  form-control-lg  ml-5" name="Usage" value="<?=old('Usage',$Usage??'')?>"/>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Why_It_required">Why It required :</label>
                                    <input type="text" id="Why_It_required" class="form-control form-control-lg" name="Why_It_required" value="<?= old('Why_It_required', $Why_It_required??'')?>"/>
                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Related_Questions">Related Questions</label>
                                    <input type="text" id="Related_Questions" class="form-control form-control-lg"  name="Related_Questions" value="<?= old('Related_Questions', $Related_Questions??'')?>"/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label for="Notes" class="form-label">Notes:</label>
                                    <textarea class="form-control  ml-5" id="Notes" name="Notes" value="<?= old('Notes', $Notes??'')?>"><?=$Notes??'';?></textarea>
                                </div>
                                <div class="col-md-6 mb-4  d-flex align-items-center">
                                    <label for="User_Story" class="form-label">User Story:</label>
                                    <textarea class="form-control  " id="User_Story" name="User_Story" value="<?= old('User_Story', $User_Story??'')?>"> <?=$User_Story??'';?></textarea>
                                </div>
                            </div>
                    </div>

                    <div class="pb-3 text-center">
                        <input class="btn btn-danger"
                            onclick=location.href="<?= base_url("customer/$id/user-story") ?>" type="button"
                            value="Cancel" />
                        <input class="btn btn-success" type="submit" value="Submit" />

                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?$this->EndSection();


$this->section('scripts');?>

<?$this->EndSection();
$this->section('dependencies');?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->

<?$this->EndSection();
$this->section('style');?>
<?$this->EndSection()?>