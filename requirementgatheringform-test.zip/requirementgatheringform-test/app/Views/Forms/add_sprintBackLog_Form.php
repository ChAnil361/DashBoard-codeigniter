<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>

<section class="pt-4">
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 col-lg-9 col-xl-7">
                <div class="card shadow-lg mb-5 bg-white rounded" style="border-radius: 16px;border-top: 5px solid #7de5325e;border-style:solid dashed dashed">
                    <div class="card-body pb-2 p-md-3">
                        <h3 class="pb-2 text-center"><?=$Form_heading;?></h3>
                        <form method="POST">
                        <?= csrf_field() ?>
                        <input type="hidden"  name="Customer_id" value="<?=old('Customer_id',$id??'');?>">
                            <? 
                            if(session()->has('errors')){
                        echo '<div class="alert alert-danger" role="alert">';
                        foreach (session('errors') as $error){
                            echo "* \t $error"."<br/>";
                            } 
                            echo '</div>';
                            }
                             ?>
                             
                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">

                                    <label class="form-label" for="Task_Name">Task Name:</label>
                                    <input type="text" id="Task_Name" class="form-control form-control-lg ml-5" name="Task_Name" value="<?=old('Task_Name',$Task_Name??'')?>"/>

                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Tab_Name">Tab Name</label>
                                    <input type="text" id="Tab_Name" class="form-control  form-control-lg  ml-5" name="Tab_Name" value="<?=old('Tab_Name',$Tab_Name??'')?>"/>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Menu_Name">Menu Name:</label>
                                    <input type="text" id="Menu_Name" class="form-control form-control-lg" name="Menu_Name" value="<?= old('Menu_Name', $Menu_Name??'')?>"/>
                                </div>
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label class="form-label" for="Sub_Menu">Sub Menu Name</label>
                                    <input type="text" id="Sub_Menu" class="form-control form-control-lg"  name="Sub_Menu" value="<?= old('Sub_Menu', $Sub_Menu??'')?>"/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label for="Tables_List" class="form-label">Tables List:</label>
                                    <input type="text" class="form-control  ml-5" id="Tables_List" name="Tables_List" value="<?= old('Tables_List', $Tables_List??'')?>"> 
                                </div>
                                <div class="col-md-6 mb-4  d-flex align-items-center">
                                    <label for="File_List" class="form-label">File List:</label>
                                    <input type="text" class="form-control  " id="File_List" name="File_List" value="<?= old('File_List', $File_List??'')?>"> 
                                </div>
                            </div>
                    </div>

                    <div class="row">
                                <div class="col-md-6 mb-4 d-flex align-items-center">
                                    <label for="Dev_description" class="form-label">Development description :</label>
                                    <input type="text" class="form-control  ml-5" id="Dev_description" name="Dev_description" value="<?= old('Dev_description', $Dev_description??'')?>"> 
                                </div>
                                <div class="col-md-6 mb-4  d-flex align-items-center">
                                    <label for="Man_Hours" class="form-label">Man Hours:</label>
                                    <input type="text" class="form-control  " id="Man_Hours" name="Man_Hours" value="<?= old('Man_Hours', $Man_Hours??'')?>"> 
                                </div>
                            </div>
                    </div>
                    <div class="pb-3 text-center">
                        <input class="btn btn-danger"
                            onclick=location.href="<?= base_url("customer/$id/sprint-backlog") ?>" type="button"
                            value="Cancel" />
                        <input class="btn btn-success" type="submit" value="Submit" />

                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?$this->EndSection();


$this->section('scripts');?>

<?$this->EndSection();
$this->section('dependencies');?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->

<?$this->EndSection();
$this->section('style');?>
<?$this->EndSection()?>