<!-- <body class="container bg-light"> -->
<!-- Start Header form -->


<div class="container-fluid bg-light">
  <div class="text-center pt-2 ">
    <a href="<?= $_ENV['Company_URL']; ?>"><img src="<?= base_url(); ?>assets/images/logo.jpg" alt="network-logo"
        class="rounded-circle" width=80 hieght=80 /></a>
    <h2> Requirement Gathering - ConVox</h2>
  </div>
  <div class="card">
    <div class="card-header text-center h5">
      Customer Profile
    </div>
    <div class="card-body">

      <? 
        if(session()->has('errors')){
      echo '<div class="alert alert-danger" role="alert">';
      foreach (session('errors') as $error){
         echo "* \t $error"."<br/>";
        } 
        echo '</div>';
        }
      ?>

      <form class="d-block" id="Profile_From" method='POST' action="<?= route_to('customer.profile'); ?>">
      <?= csrf_field() ?>
      <div class="row">
          <div class="form-group col-6">
            <label for="customer_type">Customer Typer: <span class="required ">*</span> </label>


            <select class="form-select" name='customer_type' id="customer_type" aria-label="Default select example">
              <option value=''>--Select--</option>
              <? foreach ($customer_Type as $type) {
                 $sel=old('customer_type', $customer_type)==$type?"selected":"";  
             
                echo "<option value='$type' $sel>$type</option>";
              } ?>
            </select>
          </div>

          <div class="form-group col-6">
            <label for="acc_no">Account Number:</label>
            <span id="AcctNoSpan"><input type="text" class="form-control form-control-md" id="acc_no" name="acc_no" value="<?= old('acc_no', $acc_no)?>"></span>
          </div>
          <div class="form-group col-6">
            <label for="customer_name">Customer Name</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?= old('customer_name', $customer_name)?>">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_name">SPOC Name:</label>
            <!-- <input type="text" class="form-control" id="spoc_name" name="spoc_name"> -->
            <select class="form-select" aria-label="Default select example" id="spoc_name" name="spoc_name">
              <option value=''>--Select--</option>

              <?
              foreach ($users['names'] as $id => $name) {
               $sel=old('spoc_name',$spoc_name)==$id?"selected":"";  
                echo "<option value=$id $sel>$name</option>";
              }
              ?>
            </select>
          </div>
          <div class="form-group col-6">
            <label for="ba_name">BA Name:</label>
            <!-- <input type="text" class="form-control" id="ba_name" name="ba_name"> -->
            <select class="form-select" aria-label="Default select example" id="ba_name" name="ba_name">
              <option value=''>--Select--</option>

              <?
              foreach ($users['names'] as $id => $name) {
                
               $sel=old('ba_name', $ba_name)==$id?"selected":"";  
                echo "<option value=$id $sel>$name</option>";
              }
              ?>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_phno">SPOC Contact Number:</label>
            <input type="text" class="form-control" id="spoc_phno" name="spoc_phno" value="<?=old('spoc_phno', $spoc_phno);?>">
          </div>
          <div class="form-group col-6">
            <label for="ba_phno">BA Contact Number:</label>
            <input type="text" class="form-control" id="ba_phno" name="ba_phno"  value="<?=old('ba_phno', $ba_phno);?>">
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="spoc_mail">SPOC Email ID:</label>
            <input type="text" class="form-control" id="spoc_mail" name="spoc_mail" value="<?=old('spoc_mail',$spoc_mail);?>">
          </div>
          <div class="form-group col-6">
            <label for="ba_mail">BA Email ID:</label>
            <input type="text" class="form-control" id="ba_mail" name="ba_mail" value="<?=old('ba_mail', $ba_mail);?>">
          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="industry">Process Related To(Industry) :</label>
            <!-- <input type="text" class="form-control" id="lastName" name="lastName"> -->
            <select class="form-select" aria-label="Default select example" id="industry" name="industry">
              <option value=''>--Select--</option>
              <?
              foreach ($industry_details as $key => $industry) {

                $sel=old('industry', $industry)==$industry->id?"selected":"";  
             
                echo "<option value=$industry->id $sel>$industry->name-$industry->type</option>";
              }
              ?>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-6">
            <label for="proposed_sys">Proposed System:</label>
            
            <select class="form-select" aria-label="Default select example" name="proposed_sys" id="proposed_sys">
              <option value="0">--Select--</option>
              <? foreach ($proposed_system as $key => $proposed_val) {
                
                $sel=old('industry',$proposed_sys)==$proposed_val?"selected":"";
                echo "<option value='$proposed_val' $sel>$proposed_val</option>";
              } ?>
            </select>
          </div>
          <div class="form-group col-6">


            <label for="setup">Set Up:</label>

            <select class="form-select" aria-label="Default select example" id="setup" name="setup">
              <option value=''>--Select--</option>
              <? foreach ($setups as $key => $setup_val) {
                 $sel=old('setup',$setup)==$setup_val?"selected":"";
          
                echo "<option value='$setup_val' $sel>$setup_val</option>";
              } ?>
            </select>

          </div>
        </div>


        <div class="row">
          <div class="form-group col-6">
            <label for="product_type">Product Type:</label>
            <select class="form-select" aria-label="Default select example" id="product_type" name="product_type">
              <option value="">--Select--</option>
              <? foreach ($product_details['productName'] as $key => $name) {
                 $sel=old('setup', $product_type)==$key?"selected":"";
                echo "<option value='$key' $sel>$name</option>";

              } ?>
            </select>
          </div>

          <div class="form-group col-6">
            <label for="product_version">Product Version:</label>
            <select class="form-select" aria-label="Default select example" id="product_version" name="product_version">
              <option value=''>--Select--</option>
              <? foreach ($product_details['productVersions'][''] as $key => $version) {
                echo "<option value=$key>$version</option>";
              } ?>
            </select>

          </div>
        </div>

        <div class="row">
          <div class="form-group col-6">
            <label for="usage">Usage:</label>
            <select class="form-select" aria-label="Default select example" id="usage" name="usage">
              <option value=''>--Select--</option>
              <?
              foreach ($usage as $key => $useage) {
                $sel=old('usage',$usage)==$useage?"selected":"";
                echo "<option value='$useage' $sel>$useage</option>";
              }
              ?>
            </select>
          </div>
          <div class="form-group col-6">
            <label for="firstName">Sale Manager:</label>
            <input type="text" class="form-control" id="sale_manager" name="sale_manager" value="<?=old('sale_manager', $sale_manager);?>">
          </div>
        </div>
        <div class="row text-center">
          <div class="col p-3">
            <button type="button" class="btn btn-danger">Cancel</button>
            <button type="submit" class="btn btn-success m-2">Save</button>
          </div>
        </div>
      </form>
    </div>

  </div>


</div>
<script>
  var products = JSON.parse(`<?=json_encode($product_details);?>`);
  var users = JSON.parse(`<?=json_encode($users);?>`);

  var CrmDetails = JSON.parse(`<?=$CrmDetails;?>`);
  // console.log(CrmDetails);
  var newAcctNosDetails = JSON.parse(`<?=$CrmDetails_NEW;?>`);

  // alert();
</script>
<script src="<?= base_url(); ?>assets/js/Forms/customer_profile.js"></script>