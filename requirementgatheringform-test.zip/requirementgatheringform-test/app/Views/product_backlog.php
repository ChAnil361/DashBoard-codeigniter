<?= $this->extend('Layouts/baseLayout');
$this->section('content'); ?>


<?$this->EndSection();


$this->section('scripts');?>
 <link rel="stylesheet" type="text/css" href="/DashBoard/assets/css/DataTable/jquery.dataTables.min.css" />
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"> -->

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
  
<?$this->EndSection();

$this->section('dependencies');

(@include_once("Tables/product_backlog_Table.php")) or die("File Not Found product_backlog_Table");   
?>
<div class="row pt-1">
    <div class="col-12 text-center"> 
    <input type="button" onclick=location.href="<?= base_url("customer/$customer_id/user-story") ?>" class="btn btn-danger" value="Previous"/>     
    <input type="button" onclick=location.href="<?= base_url("customer/$customer_id/sprint-backlog") ?>"  class="btn btn-success" value="Next"/> 

    </div>
<?
$this->EndSection();
$this->section('style');?>
    <?$this->EndSection()?>