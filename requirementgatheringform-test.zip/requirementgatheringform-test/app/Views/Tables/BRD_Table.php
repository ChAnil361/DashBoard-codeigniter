
<div class="card">
    <div class="card-header text-center">BRD table <span class="btn btn-warning btn-small float-right pt-0"><i class="icon-plus icon-small" onclick=location.href="<?=base_url("customer/$customer_id/brd") ?>">ADD</i></span></div>
    <div class="card-body">
        <table id="brd_Table" class='table table-bordered table-striped  table-hover'>
            <thead>
                <tr>
                    <th>#</th>
                    <th>SNO</th>
                    <th>Process</th>
                    <th>Related_Questions</th>
                    <th>Notes</th>
                    <th>Why_It_required</th>
                    <th>User_Story</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                
            </tbody>
                <tr>
                    <td></td>
                    <th></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th class="filterhead"></th>
                    <th></th>
                </tr>
        </table>
    </div>
</div>

<script>
    $(document).ready(function () {
        customer="<?=$customer_id;?>";
        $('#brd_Table').DataTable({
            dom: 'lrtipP',
            "processing": true,
            "serverSide": true,
            pageLength: 5,
            "lengthMenu": [5, 10, 20, 50, 100, 1000],
            "ajax": {
                url:`/DashBoard/customer/DataTable/BRD?Customer_id=${customer}`,
                type:"get",
            },
            
            columnDefs: [
                {target: [0, 1],searchable: false },
            ],
            columns: [{
                    data: 'id',
                    orderable: false
                },
                {
                    data: 'sno',
                    orderable: false
                },
                {
                    data: 'Process'
                },
                {
                    data: 'Related_Questions'
                },
                {
                    data: 'Notes'
                },
                {
                    data: 'Why_It_required'
                },
                {
                    data: 'User_Story'
                },
                {
                    data: 'action',
                    orderable: false
                },
            ],
            initComplete: function (settings, json) {

                var indexColumn = 0;
                search_column=[2,3,4,5,6];
                this.api().columns(search_column).every(function () {
                    
                    
                    var column = this;
                    var input = document.createElement("input");

                    $(input).attr('placeholder', 'Search')
                        .addClass('form-control form-control-sm')
                        .appendTo($('.filterhead:eq(' + indexColumn + ')').empty())
                        .on('keyup', function () {
                            column.search($(this).val(), false, false, true).draw();
                        });

                    indexColumn++;
                });
            }


        });
    });
</script>