
<div class="card">
    <div class="card-header text-center">FRD table <span class="btn btn-warning btn-small float-right pt-0"><i class="icon-plus icon-small" onclick=location.href="<?=base_url("customer/$customer_id/frd") ?>">ADD</i></span></div>
    <div class="card-body">
        <table id="frd_Table" class='table table-bordered table-striped  table-hover'>
            <thead>
                <tr>
                    <th>#</th>
                    <th>SNO</th>
                    <th>Modules</th>
                    <th>Feature Name</th>
                    <th>Sub Feature</th>
                    <th>Solution Proposed</th>
                    <th>Should be a part of main package</th>
                    <th>Owner</th>
                    <th>Man Hours</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                
            </tbody>
                <tr>
                    <td></td>
                    <th></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th class="filterhead_frd"></th>
                    <th></th>
                </tr>
        </table>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#frd_Table').DataTable({
            dom: 'lrtipP',
            "processing": true,
            "serverSide": true,
            pageLength: 5,
            "lengthMenu": [5, 10, 20, 50, 100, 1000],
            method: 'POST',
            "ajax":{ 
                url:`/DashBoard/customer/DataTable/FRD?Customer_id=${customer}`,
            },
            
            columnDefs: [
                {target: [0, 1],searchable: false },
            ],

            columns: [{
                    data: 'id',
                    orderable: false
                },
                {
                    data: 'sno',
                    orderable: false
                },
                {
                    data: 'Module Name', 
                },
                {
                    data: 'Feature Name'
                },
                {
                    data: 'Sub Feature Name'
                },
                
                {
                    data: 'Solution_Proposed'
                },
                {
                    data: 'main_package'
                },
                {
                    data: 'BA_id'
                },
                {
                    data: 'Man_Hours'
                },
                {
                    data: 'action',
                    orderable: false
                },
            ],
            initComplete: function (settings, json) {

                var indexColumn = 0;
                search_column=[2,3,4,5,6,7,8,9];
                this.api().columns(search_column).every(function () {
                    
                    
                    var column = this;
                    var input = document.createElement("input");

                    $(input).attr('placeholder', 'Search')
                        .addClass('form-control form-control-sm')
                        .appendTo($('.filterhead_frd:eq(' + indexColumn + ')').empty())
                        .on('keyup', function () {
                            column.search($(this).val(), false, false, true).draw();
                        });

                    indexColumn++;
                });
            }


        });
    });
</script>