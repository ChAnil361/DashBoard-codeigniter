<?php

namespace App\Traits;

// use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Events\Dispatcher;
use Illuminate\Container\Container;
/**
 * 
 */

 trait EloquentTrait
 {
    /**
     * @function used to Eloquent(Laravel) Concepts i.e ORM
     */
      public static function eloquent()
      {
          $capsule = new Capsule;
          $conf = Config('Database');
          //DBDriver
          $capsule->addConnection([
              'driver'    => 'mysql',
              'host'      =>  $conf->default['hostname'],
              'database'  => $conf->default['database'],
              'username'  =>  $conf->default['username'],
              'password'  => $conf->default['password'],
              'charset'   => $conf->default['charset'],
              'collation' => $conf->default['DBCollat'],
              'prefix'    => $conf->default['DBPrefix'],
          ]);
      
          $capsule->setEventDispatcher(new Dispatcher(new Container));
          $capsule->setAsGlobal();
          $capsule->bootEloquent();
      
          return $capsule;
      }
 }
 