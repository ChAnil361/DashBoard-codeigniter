<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CustomerDetails extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'Cmr_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'index' => true,
            ],
            'CRM_Account_Number' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
            ],
            'CRM_Account_name' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
            ],
            'Product_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'index' => true,
            ],
            'industry_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'Hosting_Type' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
            ],
            'dialingType' => [
                'type' => 'VARCHAR',
                'constraint' => 40,
            ],
            'Pusages' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'ba_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'SPOC_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true, 
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('Product_id', 'productDetails', 'id');
        
        $this->forge->addForeignKey('Cmr_id', 'crmdetails', 'id');

        $this->forge->addForeignKey('industry_id', 'industry_details', 'id');
        // $this->forge->addForeignKey('ba_id', 'user_details_dash_board', 'id');
        // $this->forge->addForeignKey('SPOC_id', 'user_details_dash_board', 'id');
        
        $this->forge->createTable('customerDetails');
        $this->db->query("ALTER TABLE customerDetails MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        $this->db->ForeignKeyChecks(1);
       
    }

    public function down()
    {
        //
        $this->forge->dropTable('customerDetails');
    }
}
