<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Database\Migrations\Features;
use App\Models\Feature;

use App\Requests\Forms\CreateProductBackLogRequest;
use App\Services\ProductBackLogService;

class ProductBacklogController extends BaseController
{

    public function __construct(ProductBackLogService $productService=null)
    {

        $this->service=$productService ?? new ProductBackLogService;
    }

    public function index($id)
    {
        //
        $data['customer_id']=$id;

      return   view("product_backlog",$data);
    }

    public function show($id)
    {  
        $data['id']=$id;
        $data['Module']=$this->service->getModules();
        $data['subModule']=$this->service->getSubModule();
        $data['features_data']=Feature::all();
        $data['owner']=session()->get('name');
        $data['Form_heading']="Add Product BackLog";
        return view('Forms/add_productBackLog_Form',$data);
        // display a single user story based on the given ID
    }

    /**
     * 
     */
    public function  create()
    {

        $brdRequest=new CreateProductBackLogRequest();

        $errors=$brdRequest->validation();

       
        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            }
 
            $request_data=$this->request->getPost();
           
            $is_created=$this->service->createProductBackLog($request_data);
    
            
            if(!$is_created){
            session()->setFlashdata('message', 'error|something wen wrong');
            
            return redirect()->back()->withInput()->with('errors',$errors);
            }

            $success_message = 'success|Your Record has been submitted successfully.';
            session()->setFlashdata('message', $success_message);
            
            return redirect()->route('productBacklog.show',[$request_data['Customer_id']]);

    }

    public function edit($customer_id,$id){
         $product_data=$this->service->findProductBackLog($id);
       
     $sub_module_options=$this->service->findParentSubModules($product_data->module_id);
        $data=[
            'Form_heading'=>"Edit Product BackLog",
            "id"=>$customer_id,
            "Module"=>$this->service->getModules(), 
            "features_data"=>Feature::all(),
            "subModule"=>$this->service->getSubModule(),
            "task_name"=>$product_data->task_name,
            "task_description"=>$product_data->task_description,
            "owner"=>session()->get('name'),
            "feature"=>$product_data->feature_id,
            "module"=>$product_data->module_id,
            "sub_module"=>$product_data->smodule_id,
            "subModule_options"=>array_key_exists($product_data->module_id,$sub_module_options)?$sub_module_options[$product_data->module_id]:[],
            "man_hours"=>$product_data->man_hours
             ]; 

             return view('Forms/add_productBackLog_Form',$data);
    }

    public function update(int $customer_id,int $product_backlog_id)
    {

        $brdRequest=new CreateProductBackLogRequest();

        $errors=$brdRequest->validation();

       
        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            }
    
            $request_data=$this->request->getPost();

             $is_updated=$this->service->updateProductBackLog($product_backlog_id,$request_data);
             if(!$is_updated){
                session()->setFlashdata('message', 'error|something wen wrong');
                return redirect()->back()->withInput()->with('errors',$errors);
                }
            session()->setFlashdata('message', 'success|Your Record deleted successfully.');


            return redirect()->route('productBacklog.show',[$customer_id]);
    }



    public function destroy($customer_id,int $product_id)
    {
    //  $this->service->findProductBackLog($product_id)->;

        $is_delete=$this->service->deleteProductBacklog($product_id);

        if(!$is_delete){
            session()->setFlashdata('message', 'error|something wen wrong');
            return redirect()->back()->withInput()->with('errors','');
            }

            session()->setFlashdata('message', 'success|Your Record deleted successfully.');
            return redirect()->route('productBacklog.show',[$customer_id,$product_id]);
     }





}