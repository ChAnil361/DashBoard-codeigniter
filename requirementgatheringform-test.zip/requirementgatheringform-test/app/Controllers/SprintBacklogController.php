<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Requests\Forms\CreateSprintBackLogRequest;
use \App\Services\SprintBackLogService;
class SprintBacklogController extends BaseController
{

    function __construct(SprintBackLogService $sprintbackLogService=null){
        $this->service = $sprintbackLogService ?? new SprintBackLogService();  
    }


    public function index($id)
    {
        //
        $data['customer_id']=$id; 
        return view('sprint_backlog',$data);
    }

    public function show($id)
    {
        
        $data['id']=$id;
        $data['Form_heading']="Add Sprint BackLog";
        return view('Forms/add_sprintBackLog_Form',$data);

        // display a single user story based on the given ID
    }

public function create(){
    $request=new CreateSprintBackLogRequest();

    $errors=$request->validation();
   
    if(!$errors){
         $errors= $request->getErrors();
         session()->setFlashdata('message', 'error|something wen wrong');
         
        // return redirect()->back()->withInput()->with('errors',$errors);
        }

        $request_data=$this->request->getPost();
       
        $is_created=$this->service->createSprint($request_data);
        
        if(!$is_created){
        session()->setFlashdata('message', 'error|something wen wrong');
        
        return redirect()->back()->withInput()->with('errors',$errors);
        }

        $success_message = 'success|Your Record has been submitted successfully.';
        session()->setFlashdata('message', $success_message);
        
        return redirect()->route('sprintBacklog.show',[$request_data['Customer_id']]);

}


    /**
     * 
     */
    public function edit($id,$sprint_id)
    {
          
        $sprint_data=$this->service->findSprint($sprint_id);

        $data=[
            "id"=>$id,
            "Task_Name"=>"",
            "Tab_Name"=>$sprint_data->Tab_Name,
            "Menu_Name"=>$sprint_data->Menu_Name,
            "Sub_Menu"=>$sprint_data->Sub_Menu,
            "Tables_List"=>$sprint_data->Tables_List,
            "File_List"=>$sprint_data->File_List,
            "Dev_description"=>"No column",
            "Man_Hours"=>10,
            "Form_heading"=>"EDIT Sprint BackLog"
        ];

        return view('Forms/add_sprintBackLog_Form',$data); 
    }


    public function update(int $customer_id,int $sprint_backlog_id){
        
        $brdRequest=new CreateSprintBackLogRequest();

        $errors=$brdRequest->validation();

       
        if(!$errors){
             $errors= $brdRequest->getErrors();
             session()->setFlashdata('message', 'error|something wen wrong');
             
            return redirect()->back()->withInput()->with('errors',$errors);
            }
    
            $request_data=$this->request->getPost();

             $is_updated=$this->service->updateSprint($sprint_backlog_id,$request_data);
          
             if(!$is_updated){
                session()->setFlashdata('message', 'error|something wen wrong');
                return redirect()->back()->withInput()->with('errors',$errors);
                }
          
                session()->setFlashdata('message', 'success|Your Record deleted successfully.');


            return redirect()->route('sprintBacklog.show',[$customer_id]);

    }



    public function destroy($customer_id,int $sprint_id)
    {
    //  $this->service->findProductBackLog($product_id)->;
 
        $is_delete=$this->service->deleteSprint($sprint_id);

        if(!$is_delete){
            session()->setFlashdata('message', 'error|something wen wrong');
            return redirect()->back()->withInput()->with('errors','');
            }

            session()->setFlashdata('message', 'success|Your Record deleted successfully.');
            return redirect()->route('sprintBacklog.show',[$customer_id,$sprint_id]);
     }


}
