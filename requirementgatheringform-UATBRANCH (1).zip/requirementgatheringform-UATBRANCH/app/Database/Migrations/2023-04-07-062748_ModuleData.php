<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ModuleData extends Migration
{ 
    public function up()
        {
            $this->db->ForeignKeyChecks(0);
            $this->forge->addField([
                'id'      => [
                    'type'           => 'INT',
                    'constraint'     => 11,
                    'unsigned'       => true,
                    'auto_increment' => true,
                ],
                'name'    => [
                    'type'       => 'VARCHAR',
                    'constraint' => 20,
                ],
                'pid'     => [
                    'type'       => 'INT',
                    'constraint' => 10,
                ],
                'fid'     => [
                    'type'       => 'BIGINT',
                ],
            ]);

            $this->forge->addForeignKey('pid', 'product_details', 'id');
            $this->forge->addForeignKey('fid', 'features', 'id');
            $this->forge->addKey('id', true);
            $this->forge->createTable('Modules');

            $this->db->ForeignKeyChecks(1);
        }

        public function down()
        {
            $this->forge->dropTable('Modules');
        }
}
