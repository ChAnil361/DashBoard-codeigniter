<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class SubFeature extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
            ],
            'parent_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'suggestions_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('parent_id', 'features', 'id');
        $this->forge->addForeignKey('suggestions_id', 'suggestion', 'id');
        $this->forge->createTable('sub_feature');

        $this->db->ForeignKeyChecks(1);
    }

    public function down()
    {
        //
        $this->forge->dropTable('sub_feature');
    }
}
