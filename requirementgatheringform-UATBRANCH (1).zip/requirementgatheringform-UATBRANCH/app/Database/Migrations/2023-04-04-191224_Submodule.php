<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Submodule extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $this->db->ForeignKeyChecks(0);

        $this->forge->addField('id');
        $this->forge->addField([
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'parent_id' => [
                'type' => 'INT',
            ],
        ]);
        $this->forge->addForeignKey('parent_id', 'modules', 'id');
        $this->forge->createTable('sub_module');

        $this->db->ForeignKeyChecks(1);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $this->forge->dropTable('sub_module');
    }
}
