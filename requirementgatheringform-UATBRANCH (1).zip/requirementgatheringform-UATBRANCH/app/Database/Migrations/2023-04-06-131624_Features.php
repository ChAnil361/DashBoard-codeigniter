<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Features extends Migration
{
    public function up()
    {
        //
        $this->db->ForeignKeyChecks(0);
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'unsigned' => true,
                'auto_increment' => true
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 30
            ],
            'DialingType' => [
                'type' => 'VARCHAR',
                'constraint' => 30
            ],
            'pid' => [
                'type' => 'INT',
                'unsigned' => true
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('pid', 'product_details', 'id');
        $this->forge->createTable('Features');

        $this->db->ForeignKeyChecks(1);
    }

    public function down()
    {
        //
        $this->forge->dropTable('Features');
    }
}
