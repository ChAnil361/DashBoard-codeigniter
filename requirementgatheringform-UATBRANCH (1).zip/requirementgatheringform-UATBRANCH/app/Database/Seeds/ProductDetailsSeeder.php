<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProductDetailsSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Product 1',
                'version' => '1.0',
            ],
            [
                'name' => 'Product 2',
                'version' => '2.0',
            ],
            [
                'name' => 'Product 3',
                'version' => '3.0',
            ],
        ];

        $this->db->table('productDetails')->insertBatch($data);
    }
}
