<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class FeatureSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'name' => 'Feature 1',
                'DialingType' => 'Type A',
                'pid' => 1
            ],
            [
                'name' => 'Feature 2',
                'DialingType' => 'Type B',
                'pid' => 1
            ],
            [
                'name' => 'Feature 3',
                'DialingType' => 'Type A',
                'pid' => 2
            ],
            [
                'name' => 'Feature 4',
                'DialingType' => 'Type C',
                'pid' => 2
            ]
        ];

        $this->db->table('Features')->insertBatch($data);
    }
}
