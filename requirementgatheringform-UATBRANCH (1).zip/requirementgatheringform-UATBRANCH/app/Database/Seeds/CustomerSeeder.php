<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run()
    {
        //
        $data = [
            [
                'CRM_Account_Number' => '1001',
                'CRM_Account_name' => 'Acme Inc.',
                'Product_id' => 1,
                'industry_id' => 2,
                'Hosting_Type' => 'shared',
                'pUsages' => 'low',
                'dialingType' => 'manual',
                'ba_id' => 1,
                'SPOC_id' => 2
            ],
            [
                'CRM_Account_Number' => '1002',
                'CRM_Account_name' => 'Globex Corporation',
                'Product_id' => 2,
                'industry_id' => 1,
                'Hosting_Type' => 'dedicated',
                'pUsages' => 'high',
                'dialingType' => 'automatic',
                'ba_id' => 2,
                'SPOC_id' => 1
            ]
        ];

        $this->db->table('customerDetails')->insertBatch($data);
    }
}
