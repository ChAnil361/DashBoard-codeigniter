<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserStorySeeder extends Seeder
{
    public function run()
    {
        //
        // Load the Faker library
        $faker = \Faker\Factory::create();

        // Load the database
        $this->db = \Config\Database::connect();

        // Empty the table
        $this->db->table('user_story')->truncate();

        // Seed the table with random data
        for ($i = 1; $i <= 10; $i++) {
            $data = [
                'customer_id' => $faker->numberBetween(1, 5),
                'feature_id'  => $faker->numberBetween(1, 3),
            ];
            $this->db->table('user_story')->insert($data);
        }

    }
}
