<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CustomerDetailsSeeder extends Seeder
{
    public function run()
    {
        //
        
        $data = [
            [
                'CRM_Account_Number' => '1234567890',
                'CRM_Account_name' => 'Acme Corporation',
                'Product_id' => 1,
                'industry_id' => 2,
                'Hosting_Type' => 'Cloud',
                'dialingType' => 'Outbound',
                'Pusages' => 'High',
                'ba_id' => 3,
                'SPOC_id' => 4,
            ],
            [
                'CRM_Account_Number' => '0987654321',
                'CRM_Account_name' => 'XYZ Inc.',
                'Product_id' => 2,
                'industry_id' => 1,
                'Hosting_Type' => 'On-Premises',
                'dialingType' => 'Inbound',
                'Pusages' => 'Low',
                'ba_id' => 4,
                'SPOC_id' => 3,
            ],
            [
                'CRM_Account_Number' => '5678901234',
                'CRM_Account_name' => 'Foo Industries',
                'Product_id' => 3,
                'industry_id' => 3,
                'Hosting_Type' => 'Hybrid',
                'dialingType' => 'Outbound',
                'Pusages' => 'Medium',
                'ba_id' => 2,
                'SPOC_id' => 5,
            ],
        ];

        $this->db->table('customerDetails')->insertBatch($data);
    }
}
