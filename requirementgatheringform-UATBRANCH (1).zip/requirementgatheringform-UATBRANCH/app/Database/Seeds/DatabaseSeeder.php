<?php namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->db->ForeignKeyChecks(0);

        $seeder=['CustomerDetailsSeeder','FeatureSeeder','SuggestionSeeder',
                'IndustryDetailsSeeder','ModulesSeeder','ProductBackLogSeeder',
                'SprintBacklogSeeder','SubFeatureSeeder','SubmoduleSeeder',
                'UserStorySeeder','ProductDetailsSeeder'];
        foreach($seeder as $seed)
        {
                $this->call($seed);
        } 
            $this->db->ForeignKeyChecks(1);

    }
}
