<?php
namespace App\Controllers;
use \App\Models\ProductVersionModel;
class ProductVersionController extends BaseController
{  
    public function index()
    {
        if( $this->request->is('post') ) { 
           $data = [];
            $product_id = $this->request->getVar('product_id',FILTER_SANITIZE_STRING);
           $product_v_model_obj =  new ProductVersionModel();
           $product_v = $product_v_model_obj->get_product_version_by_id($product_id);
          $data['product_versions'] = $product_v;
          return view('product_version_view',$data);
        }
    }
}