<?php
namespace App\Controllers;
use \App\Models\BaDetails;
use \App\Models\IndustryModel;
use \App\Models\ProductModel;
use \App\Models\CustomerModel;
use \App\Models\ProductVersionModel;
class CustomerProfileController extends BaseController
{  

    public function index(){
      // check if customer exist and redirect
     $ticket_number = session()->get('ticket_number');
     $customerModelObj = new CustomerModel();
     $customer_array = $customerModelObj->checkIfCustomerExist($ticket_number);
     $arr_size = sizeof($customer_array);
     if($arr_size > 0){
       $data['customer'] = $customer_array;
      $product_name_id = $customer_array[0]["product_name"];
      $product_version_id = $customer_array[0]["product_version"]; 
     $productModel_obj = new ProductModel();
     $product_name_array = $productModel_obj->get_product_name_by_id($product_name_id);
     $producVersiontModel_obj = new ProductVersionModel();
     $product_version_array = $producVersiontModel_obj->get_product_version_name_by_id($product_version_id);
     $data['product_name'] = $product_name_array;
     $data['product_version'] = $product_version_array;
       return view('existing-customer-profile.php', $data);
     }
     /// end checking and redirecting
        $data = [];
        $ba_details = new BaDetails();
        $industry_details = new IndustryModel();
        $product_details = new ProductModel();
        $username = session()->get('username');
        $ba_data = $ba_details->get_ba_details($username);
        $industry_data  = $industry_details->get_industry_array();
        $product_data  = $product_details->get_product_array();
        $data['ba_details'] = $ba_data;
        $data['industry_details'] = $industry_data;
        $data['product_details'] = $product_data;
       /// validation
       $rules = [
        'spoc_name' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'SPOC Name is Required'
            ]
        ],
        'spoc_phone_number' => [
            'rules' => 'required|regex_match[/^[0-9]{10}$/]',
            'errors' => [
                'required' => 'SPOC Contact is Required ',
                'regex_match' => 'SPOC Contact Number Must be 10 Digit Long'
            ]
        ],
        'spoc_email' => [
            'rules' => 'required|valid_email',
            'errors' => [
                'required' => 'SPOC Email is Required ',
                'valid_email' => 'Invalid Email'        
            ]
        ],
        'industry_name' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Please Select Industry'
            ]
        ],
        'proposed_system' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Please Select Proposed System'
            ]
        ],
        'set_up' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Please Select Set-Up'
            ]
        ],
        'product_name' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Please Select Product Name'
            ]
        ],
        'product_version' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Select Version based on Product Name'
            ]
        ],
        'product_usage' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Please Select Product Usage'
            ]
        ],
        'sale_manager' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Enter Sale Manager Name'
            ]
        ],
        
    ];
    if( $this->request->is('post') ){
        if($this->validate($rules)){
            $customer_data = [
                'crm_account_name_number' => $this->request->getVar('crm_account_name_number',FILTER_SANITIZE_STRING),
                'spoc_name' => $this->request->getVar('spoc_name',FILTER_SANITIZE_STRING),
                'spoc_phone_number' => $this->request->getVar('spoc_phone_number',FILTER_SANITIZE_STRING),
                'spoc_email' => $this->request->getVar('spoc_email',FILTER_SANITIZE_STRING),
                'ba_name' => $this->request->getVar('ba_name',FILTER_SANITIZE_STRING),
                'ba_phone_number' => $this->request->getVar('ba_phone_number',FILTER_SANITIZE_STRING),
                'ba_email' => $this->request->getVar('ba_email',FILTER_SANITIZE_STRING),
                'industry_name' => $this->request->getVar('industry_name',FILTER_SANITIZE_STRING),
                'proposed_system' => $this->request->getVar('proposed_system',FILTER_SANITIZE_STRING),
                'set_up' => $this->request->getVar('set_up',FILTER_SANITIZE_STRING),
                'product_name' => $this->request->getVar('product_name',FILTER_SANITIZE_STRING),
                'product_version' => $this->request->getVar('product_version',FILTER_SANITIZE_STRING),
                'product_usage' => $this->request->getVar('product_usage',FILTER_SANITIZE_STRING),
                'sale_manager' => $this->request->getVar('sale_manager',FILTER_SANITIZE_STRING),
                'ba_user_id' => $this->request->getVar('ba_username',FILTER_SANITIZE_STRING),
                'ticket_number' => $this->request->getVar('ticket_number',FILTER_SANITIZE_STRING),  
            ];
            $add_customer_profile = new CustomerModel();
            $status = $add_customer_profile->saveData($customer_data);
            if( $status ){
                $brd_url = base_url()."brd";
               return redirect()->to($brd_url);
            }
            else{
                $this->session->setTempdata('error','Something went wrong! Please try again.',3);
                return redirect()->to(base_url()."customer_profile");
            }
        }else{
            $data["validation"] = $this->validator;
        }
    }
        return view('customer_profile',$data); 
    }



}
?>