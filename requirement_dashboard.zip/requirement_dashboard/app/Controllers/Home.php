<?php
namespace App\Controllers;
use \App\Models\Auth;
use \App\Models\HelpDeskTickets;
use CodeIgniter\Modules\Modules;
class Home extends BaseController
{  
    public function index()
    {
        if(session()->get('username')){
             $dashboard_url = base_url()."customer_profile";
            return redirect()->to($dashboard_url);
       }
        return view('login');
    }

    public function auth($id){ 
       $helpDeskTicketsObj = new HelpDeskTickets();
       $result = $helpDeskTicketsObj->get_ticket_details($id);
       if(sizeof($result) > 0){
        $ticket_number = $result[0]['ticket_number']; 
        $username = $result[0]['user_name'];
        $customer_name = $result[0]['dtel_customer'];
         $sessiondata = [
            'username'  => $username,
            'customer_name' => $customer_name,
            'ticket_number' => $ticket_number,
            'logged_in' => true
        ];
        $this->session->set($sessiondata);
         $dashboard_url = base_url()."customer_profile";
        return redirect()->to($dashboard_url);
    }else{
        return view('login');
    }

    }
}
