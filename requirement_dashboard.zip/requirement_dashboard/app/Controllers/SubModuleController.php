<?php
namespace App\Controllers;
use \App\Models\SubModuleModel;
class SubModuleController extends BaseController
{  
    public function index()
    {
        if( $this->request->is('post') ) { 
           $data = [];
            $module_id = $this->request->getVar('module_id',FILTER_SANITIZE_STRING);
           $obj =  new SubModuleModel();
           $sub_modules = $obj->get_sub_module_by_id($module_id);
          $data['sub_modules'] = $sub_modules;
          return view('sub_modules_view',$data);
        }
    }
}