<?php
namespace App\Controllers;
use \App\Models\ModuleModel;
use \App\Models\SubModuleModel;
use \App\Models\FeatureModel;
use \App\Models\ProductBacklogModel;
class ProductBacklogController extends BaseController
{  
    public function index(){
        $data = [];
        $ticket_number = session()->get('ticket_number');
        $productBacklogModelobj = new ProductBacklogModel();
        $product_backlog_array = $productBacklogModelobj->get_product_backlog_details($ticket_number);
        $data['product_backlog_array'] = $product_backlog_array;
        return view('product-backlog',$data);
    }
    public function addProductBacklog(){
        $data = [];
        $module_obj = new ModuleModel();
        $module_array = $module_obj->get_module_array();
        $data['module_array'] = $module_array;
        $feature_obj = new FeatureModel();
        $feature_array = $feature_obj->get_feature_array();
        $data['feature_array'] = $feature_array;
        if( $this->request->is('post') ){
            $product_backlog_data = [
            'as_a' => $this->request->getVar('as_a',FILTER_SANITIZE_STRING),
            'task_heading' => $this->request->getVar('task_heading',FILTER_SANITIZE_STRING),
            'task_description' => $this->request->getVar('task_description',FILTER_SANITIZE_STRING),
            'priority' => $this->request->getVar('priority',FILTER_SANITIZE_STRING),
            'module' => $this->request->getVar('module',FILTER_SANITIZE_STRING),
            'sub_module' => $this->request->getVar('sub_module',FILTER_SANITIZE_STRING),
            'feature_name' => $this->request->getVar('feature',FILTER_SANITIZE_STRING),
            'estimated_hours' => $this->request->getVar('estimated_hours',FILTER_SANITIZE_STRING),
            'task_owner' => $this->request->getVar('task_owner',FILTER_SANITIZE_STRING),
            'crm_account_name_number' => $this->request->getVar('crm_account_name_number',FILTER_SANITIZE_STRING),
            'ticket_number' => $this->request->getVar('ticket_number',FILTER_SANITIZE_STRING),    
            ];
            $product_backlog_obj = new ProductBacklogModel();
            $status = $product_backlog_obj->saveData($product_backlog_data);
            if( $status ){
                $product_backlog_url = base_url()."product-backlog";
               return redirect()->to($product_backlog_url);
            }
            else{
                $this->session->setTempdata('error','Something went wrong! Please try again.',3);
                return redirect()->to(base_url()."add-product-backlog");
            }

        }
        return view('add-product-backlog',$data);
    }
}