<?php
namespace App\Controllers;
use \App\Models\BRDModel;
class BrdController extends BaseController
{  
    public function index()
    {
     $data = [];
     $brdobj  = new BRDModel();
     $ticket_number = session()->get('ticket_number');
     $brd_data = $brdobj->get_brd_details($ticket_number); 
     $data['brd_data'] = $brd_data;
     return view('brd',$data);
    }
    public function addBrd()
    {

        if( $this->request->is('post') ){
            $brd_data = [
                'process' => $this->request->getVar('process',FILTER_SANITIZE_STRING),
                'product_usage' => $this->request->getVar('product_usage',FILTER_SANITIZE_STRING),
                'requirement_heading' => $this->request->getVar('requirement_heading',FILTER_SANITIZE_STRING),
                'requirement_description' => $this->request->getVar('requirement_description',FILTER_SANITIZE_STRING),
                'ba_userid' => $this->request->getVar('ba_userid',FILTER_SANITIZE_STRING),
                'crm_account_name_number' => $this->request->getVar('crm_account_name_number',FILTER_SANITIZE_STRING),
                'ticket_number' => $this->request->getVar('ticket_number',FILTER_SANITIZE_STRING),
            ];
            $add_customer_profile = new BRDModel();
            $status = $add_customer_profile->saveData($brd_data);
            if( $status ){
                $brd_url = base_url()."brd";
               return redirect()->to($brd_url);
            }
            else{
                $this->session->setTempdata('error','Something went wrong! Please try again.',3);
                return redirect()->to(base_url()."customer_profile");
            }

        }
        return view('add-brd');
    }

}