<?php

namespace App\Models;

use CodeIgniter\Model;

class BrdModel extends Model
{
    public function saveData($data){
        $db = \Config\Database::connect();
        $builder = $db->table('brd');
        $result = $builder->insert($data);   
        if($result){
          return true; 
        }else{
              return false;
        }
    }


    public function get_brd_details($ticket_number){
        $DB = \Config\Database::connect();
        $query = $DB->query("SELECT *FROM brd WHERE ticket_number = '$ticket_number'");
        $result = $query->getResultArray();
        return $result;
      }


}