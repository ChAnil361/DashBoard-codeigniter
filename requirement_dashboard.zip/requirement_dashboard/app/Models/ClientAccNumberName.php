<?php
namespace App\Models;
use CodeIgniter\Model;
class ClientAccNumberName extends Model
{
   public function get_client_ac_number_name(){
       $vtigerDB = \Config\Database::connect('vtigerDB');
       $query = $vtigerDB->query("SELECT account_no,accountname FROM vtiger_account");
       $result = $query->getResult();
       return $result;
    }

}


?>