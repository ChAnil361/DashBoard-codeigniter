<?php
namespace App\Models;
use CodeIgniter\Model;
class IndustryModel extends Model
{
   public function get_industry_array(){
       $db = \Config\Database::connect();
       $query = $db->query("select industry_name from industry_master");
       $result = $query->getResultArray();
       return $result;
    }


}


?>