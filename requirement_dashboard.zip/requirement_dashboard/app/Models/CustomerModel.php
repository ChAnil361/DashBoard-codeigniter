<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    public function saveData($data){
        $db = \Config\Database::connect();
        $builder = $db->table('customer_profile');
        $result = $builder->insert($data);   
        if($result){
          return true; 
        }else{
              return false;
        }
    }



    public function checkIfCustomerExist($ticket_number){
      $db = \Config\Database::connect();
      $query = $db->query("SELECT *FROM customer_profile WHERE ticket_number = '$ticket_number' LIMIT 1");
      $result = $query->getResultArray();
      return $result; 
  }


}