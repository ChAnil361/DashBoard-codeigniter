<?php
namespace App\Models;
use CodeIgniter\Model;
class Auth extends Model
{
   public function get_records_from_db($user_name){
       $vtigerDB = \Config\Database::connect('vtigerDB');
       $query = $vtigerDB->query("SELECT *FROM vtiger_users WHERE user_name = '$user_name'");
       $result = $query->getResult();
       return $result;
    }


}


?>