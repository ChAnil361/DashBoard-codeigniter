<?php
namespace App\Models;
use CodeIgniter\Model;
class SubModuleModel extends Model
{
   public function get_sub_module_by_id($module_id){
       $db = \Config\Database::connect();
       $query = $db->query("select *from sub_module_master where module_id='$module_id'");
       $result = $query->getResultArray();
       return $result;
    }

    public function get_sub_module_name_by_id($sub_module_id){
        $db = \Config\Database::connect();
        $query = $db->query("select sub_module_name from sub_module_master where sub_module_id = '$sub_module_id' ");
        $result = $query->getResultArray();
        return $result;
     }
}


?>