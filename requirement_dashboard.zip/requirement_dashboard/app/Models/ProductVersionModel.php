<?php
namespace App\Models;
use CodeIgniter\Model;
class ProductVersionModel extends Model
{
   public function get_product_version_by_id($product_id){
       $db = \Config\Database::connect();
       $query = $db->query("select *from product_versions where product_id='$product_id'");
       $result = $query->getResultArray();
       return $result;
    }

    public function get_product_version_name_by_id($product_version_id){
        $db = \Config\Database::connect();
        $query = $db->query("select product_version from product_versions where id = '$product_version_id' ");
        $result = $query->getResultArray();
        return $result;
     }
}


?>