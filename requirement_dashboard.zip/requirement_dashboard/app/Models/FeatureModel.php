<?php
namespace App\Models;
use CodeIgniter\Model;
class FeatureModel extends Model
{
   public function get_feature_array(){
       $db = \Config\Database::connect();
       $query = $db->query("select *from feature_master");
       $result = $query->getResultArray();
       return $result;
    }
    
}


?>