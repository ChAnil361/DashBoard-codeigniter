<?php
namespace App\Models;
use CodeIgniter\Model;
class ModuleModel extends Model
{
   public function get_module_array(){
       $db = \Config\Database::connect();
       $query = $db->query("select *from module_master");
       $result = $query->getResultArray();
       return $result;
    }
    public function get_module_name_by_id($module_id){
        $db = \Config\Database::connect();
        $query = $db->query("select module_name from module_master where module_id = '$module_id' ");
        $result = $query->getResultArray();
        return $result;
     }
}


?>