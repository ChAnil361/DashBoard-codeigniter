<?php
namespace App\Models;
use CodeIgniter\Model;
class HelpDeskTickets extends Model
{
   public function get_ticket_details($id){
       $helpDeskDB = \Config\Database::connect('helpDesk');
       $query = $helpDeskDB->query("SELECT ticket_number,user_name,dtel_customer FROM helpdesk_tickets where ticket_number = '$id' ");
       return $result = $query->getResultArray();
       
    }


}


?>