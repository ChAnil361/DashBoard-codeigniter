<?php
namespace App\Models;
use CodeIgniter\Model;
class BaDetails extends Model
{
   public function get_ba_details($user_name){
       $vtigerDB = \Config\Database::connect('vtigerDB');
       $query = $vtigerDB->query("SELECT user_name, first_name, last_name, phone_mobile, email1 FROM vtiger_users WHERE user_name = '$user_name'");
       $result = $query->getResultArray();
       return $result;
    }


}


?>