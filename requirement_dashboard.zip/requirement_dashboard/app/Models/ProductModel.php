<?php
namespace App\Models;
use CodeIgniter\Model;
class ProductModel extends Model
{
   public function get_product_array(){
       $db = \Config\Database::connect();
       $query = $db->query("select *from product_master");
       $result = $query->getResultArray();
       return $result;
    }
    public function get_product_name_by_id($product_id){
        $db = \Config\Database::connect();
        $query = $db->query("select product_name from product_master where product_id = '$product_id' ");
        $result = $query->getResultArray();
        return $result;
     }
}


?>