<label for="product_version" class="form-label">Product Version</label>
<select required id="product_version" name="product_version" class="form-control form-control-sm">
         <option value="">Select</option>
         <?php  foreach ($product_versions as $val):
            ?><option value="<?=$val["id"];?>"><?=$val["product_version"];?></option><?php 
         endforeach; ?>
</select>