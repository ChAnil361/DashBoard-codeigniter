<?= $this->extend('layout/base'); ?>
<? $this->section('content'); ?>
<div class="login-container">
 <br />
  <div class="login-form-container">
    <h1 class="login-head">B.A. Log In</h1>
    <div class="login-slogan"><b>Requirnment Gathering Form</b> for B.A.</div>
    <br>
    <div class="alert alert-primary">
    Please Log-in to <b>HELP DESK</b> for Authentication!
    </div>
    <div class="p-2"></div>


  </div>
</div>
<? $this->endSection(); ?>
