<label for="sub_module" class="form-label">Sub Module</label>
<select required id="sub_module" name="sub_module" class="form-control form-control-sm">
         <option value="">Select</option>
         <?php  foreach ($sub_modules as $val):
            ?><option value="<?=$val["sub_module_id"];?>"><?=$val["sub_module_name"];?></option><?php 
         endforeach; ?>
</select>