<? $this->extend('layout/base'); ?>
<? $this->section('content'); ?>
<?= $this->renderSection("loginContent"); ?> 
<? $this->endSection(); ?>