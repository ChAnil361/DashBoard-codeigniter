<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Requirnment Gathering Form </title>
    <link rel="stylesheet" href="<?=base_url();?>public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?=base_url();?>public/css/style.css" />
    <link rel="icon" href="<?=base_url();?>public/images/favicon.jpg" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   <!--google font-->
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
  </head>
  <body>
   <?= $this->renderSection("content"); ?>
   <script src="<?=base_url();?>public/js/bootstrap.min.js"></script>
   <script src="<?=base_url();?>public/js/jquery-3.7.min.js"></script>
   <script>
     $("document").ready(function(){
      
      
       $("#product_name").change(function(){
           var product_id = $("#product_name").val();
              if( product_id != "" && product_id != " " ){
                $.post('<?=base_url();?>get_product_version_by_id', { product_id:product_id }, function(data){
                      $("#product_version_div").html(data);
                 } );
              }else{
                $("#product_version_div").html(""+
        "<label for='product_version' class='form-label'>Product Version</label>" + 
        "<select required id='product_version' name='product_version' class='form-control form-control-sm'>" +
        "<option value=''>Select</option>"+
        "</select>");
              }
          });


          $("#module").change(function(){
           var module_id = $("#module").val();
              if( module_id != "" && module_id != " " ){
                $.post('<?=base_url();?>get_sub_module_by_id', { module_id:module_id }, function(data){
                      $("#sub_module_div").html(data);
                 } );
              }else{
                $("#sub_module_div").html(""+
        "<label for='sub_module' class='form-label'>Sub Module</label>" + 
        "<select required id='sub_module' name='sub_module' class='form-control form-control-sm'>" +
        "<option value=''>Select</option>"+
        "</select>");
              }
          });



 
         $("#customer_profile_form").submit(function(){
           var spoc_phone_number = $("#spoc_phone_number").val();
           if(spoc_phone_number.length === 10){
             
           }
           else{
              alert("Invalid SPOC Phone Number");
              return false;
           } 
      });




     });
   </script>
  </body>
</html>


