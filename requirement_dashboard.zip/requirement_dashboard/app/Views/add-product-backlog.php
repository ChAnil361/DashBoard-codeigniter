<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>
<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style">Add Product Backlog</h2>
  <div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">
<?php
 if( session()->getTempdata('error') ){
  ?>
   <div class="alert alert-danger">
   Something went wrong! Please try again.
   </div>
  <?php 
} 
?>
<form method="post" action="" id="customer_profile_form">
     <div class="row no-mp"> 
       <input type="hidden"  name="crm_account_name_number" class="form-control form-control-sm" value="<?=session()->get('customer_name');?>" readonly   />
       <input type="hidden"  name="task_owner" class="form-control form-control-sm" value="<?=session()->get('username');?>" readonly   />
       <input type="hidden"  name="ticket_number" class="form-control form-control-sm"  value="<?=session()->get('ticket_number');?>" readonly />
       <div class="col-md-4">
       <div class="mb-3">
        <label for="as_a" class="form-label">As a</label>
        <input type="text" id="as_a" name="as_a" class="form-control form-control-sm" required />
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="task_heading" class="form-label">I want to able to (Task Heading)</label>
        <textarea rows="1" id="task_heading" name="task_heading" class="form-control form-control-sm" required></textarea>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="task_description" class="form-label">So that (Task Description)</label>
        <textarea rows="1" id="task_description" name="task_description" class="form-control form-control-sm" required></textarea>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="priority" class="form-label">Priority</label>
        <select id="priority" name="priority" class="form-control form-control-sm" required>
            <option value="">Select</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="module" class="form-label">Module</label>
        <select id="module" name="module" class="form-control form-control-sm" required>
            <option value="">Select</option>
            <?php  foreach ($module_array as $val):
            ?><option value="<?=$val["module_id"];?>"><?=$val["module_name"];?></option><?php 
         endforeach; ?>
        </select>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3" id="sub_module_div">
        <label for="sub_module" class="form-label">Sub Module</label>
        <select id="sub_modue" required name="sub_module" class="form-control form-control-sm">
         <option value="">Select</option>
        </select>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="feature" class="form-label">Feature</label>
        <select id="feature" name="feature" class="form-control form-control-sm" required>
            <option value="">Select</option>
            <?php  foreach ($feature_array as $val):
            ?><option value="<?=$val["feature_id"];?>"><?=$val["feature_name"];?></option><?php 
         endforeach; ?>
        </select>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="estimated_hours" class="form-label">Estimated Hours</label>
        <input type="text" id="estimated_hours" name="estimated_hours" class="form-control form-control-sm" required />
        </div>
       </div>
      </div>
      <div class="d-flex justify-content-center">
      <input type="submit" id="product_backlog_save_button" class="btn btn-success btn-sm mbtn" value="Save">
      </div>
    </form>
</div>
</div>
</div>
<? $this->endSection() ?>