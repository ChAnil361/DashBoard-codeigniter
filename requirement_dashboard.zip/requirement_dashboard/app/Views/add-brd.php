<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>
<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style"> Add Business Requirements Document(BRD)</h2>
  <div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">
<?php
 if( session()->getTempdata('error') ){
  ?>
   <div class="alert alert-danger">
   Something went wrong! Please try again.
   </div>
  <?php 
} 
?>
<form method="post" action="">
     <div class="row no-mp">
     <input readonly required type="hidden" name="ba_userid" value="<?= session()->get('username'); ?>" />
     <input readonly required type="hidden" name="crm_account_name_number" value="<?= session()->get('customer_name'); ?>" />
     <input readonly required type="hidden" name="ticket_number" value="<?= session()->get('ticket_number'); ?>" />

     <div class="col-md-4">
       <div class="mb-3">
        <label for="process" class="form-label">Process</label>
        <input type="text" id="process" name="process" class="form-control form-control-sm" required />
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="product_usage" class="form-label">Usage</label>
        <select id="product_usage" name="product_usage" class="form-control form-control-sm" required>
          <option value="">Select</option>
          <option value="Incoming">Incoming</option>
          <option value="Preview">Preview</option>
          <option value="Predictive">Predictive</option>
          <option value="Progressive">Progressive</option>
        </select>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="requirement_heading" class="form-label">Requirement Heading</label>
        <input type="text" id="requirement_heading" name="requirement_heading" class="form-control form-control-sm" required />
        </div>
       </div>
       <div class="col-md-12">
       <div class="mb-3">
        <label for="requirement_description" class="form-label">Requirement Description</label>
        <textarea type="text" id="requirement_description" name="requirement_description" class="form-control form-control-sm" required></textarea>
        </div>
       </div>
    </div>
    <div class="d-flex justify-content-center">

    <a href="<?=base_url();?>brd" class="btn  btn-danger btn-sm m-1">  Back</a>  
    <input type="submit" class="btn btn-success btn-sm mbtn m-1" value="Save">
    </div>
</form>
</div>
</div>
<? $this->endSection() ?>