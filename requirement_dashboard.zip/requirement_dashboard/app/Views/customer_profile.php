<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>
<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style">Customer Profile</h2>
  <div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">
<?php
 if( session()->getTempdata('error') ){
  ?>
   <div class="alert alert-danger">
   Something went wrong! Please try again.
   </div>
  <?php 
} 
?>
<form method="post" action="" id="customer_profile_form">
     <div class="row no-mp">
      <div class="col-md-4" title="<?=session()->get('customer_name');?>">
       <div class="mb-3">
        <label for="crm_account_name_number" class="form-label"> Customer Name / Acc. Number</label>
        <input type="text" id="crm_account_name_number" name="crm_account_name_number" class="form-control form-control-sm" value="<?=session()->get('customer_name');?>" readonly   />
        </div>
       </div>
       <input type="hidden" id="ba_name" name="ba_name" value="<?= $ba_details[0]['first_name'] ?> <?= $ba_details[0]['last_name'] ?>" class="form-control form-control-sm" readonly />
       <input type="hidden" id="ba_phone_number" value="<?= $ba_details[0]['phone_mobile']; ?>" name="ba_phone_number" class="form-control form-control-sm" readonly />
       <input type="hidden" id="ba_email" name="ba_email" class="form-control form-control-sm"  value="<?= $ba_details[0]['email1']; ?>" readonly />
       <input type="hidden"  name="ba_username" class="form-control form-control-sm"  value="<?= $ba_details[0]['user_name']; ?>" readonly />
       <input type="hidden"  name="ticket_number" class="form-control form-control-sm"  value="<?=session()->get('ticket_number');?>" readonly />
       
       
       <div class="col-md-4">
       <div class="mb-3">
        <label for="spoc_name" class="form-label">SPOC Name</label>
        <input type="text" required id="spoc_name" name="spoc_name" class="form-control form-control-sm" placeholder="" />
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('spoc_name')){
         echo $validation->getError('spoc_name'); } ?>
        </span>
       </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="spoc_phone_number" class="form-label">SPOC Contact Number</label>
        <input type="text"  required id="spoc_phone_number" name="spoc_phone_number" class="form-control form-control-sm" placeholder="" />
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('spoc_phone_number')){
         echo $validation->getError('spoc_phone_number'); } ?>
        </span> 
       </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="spoc_email" class="form-label">SPOC Email ID</label>
        <input type="email" required id="spoc_email" name="spoc_email" class="form-control form-control-sm" placeholder="" />
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('spoc_email')){
         echo $validation->getError('spoc_email'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="industry_name" required class="form-label">Process Related To(Industry)</label>
        <select required id="industry_name" name="industry_name" class="form-control form-control-sm">
         <option value="">Select</option>
         <?php  foreach ($industry_details as $val):
            ?><option value="<?=$val["industry_name"];?>"><?=$val["industry_name"];?></option><?php 
         endforeach; ?>
        </select>
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('industry_name')){
         echo $validation->getError('industry_name'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label  for="proposed_system"  class="form-label">Proposed System</label>
        <select id="proposed_system" required name="proposed_system" class="form-control form-control-sm">
          <option value="">Select</option>
          <option value="Standalone">Standalone</option>
          <option value="Distributed">Distributed</option>
        </select>
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('proposed_system')){
         echo $validation->getError('proposed_system'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="set_up" class="form-label">Set Up</label>
        <select id="set_up" required name="set_up" class="form-control form-control-sm">
          <option value="">Select</option>
          <option value="On Premises">On Premises</option>
          <option value="Hosted">Hosted</option>
          <option value="Cloud">Cloud</option>
          <option value="Hybrid">Hybrid</option>
        </select>
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('set_up')){
         echo $validation->getError('set_up'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="product_name" class="form-label">Product Name</label>
        <select id="product_name" required name="product_name" class="form-control form-control-sm">
        <option value="">Select</option>
        <?php  foreach ($product_details as $val):
            ?><option value="<?=$val["product_id"];?>"><?=$val["product_name"];?></option><?php 
         endforeach; ?>
         </select>
         <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('product_name')){
         echo $validation->getError('product_name'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3" id="product_version_div">
        <label for="product_version" class="form-label">Product Version</label>
        <select id="product_version" required name="product_version" class="form-control form-control-sm">
         <option value="">Select</option>
        </select>
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('product_version')){
         echo $validation->getError('product_version'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="product_usage" class="form-label">Usage</label>
        <select required id="product_usage" required name="product_usage" class="form-control form-control-sm">
         <option value="">Select</option>
         <option value="Product sales(Outbound)">Product sales(Outbound)</option>
         <option value="Support & Services(Inbound)">Support & Services(Inbound)</option>
        </select>
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('product_usage')){
         echo $validation->getError('product_usage'); } ?>
        </span>
        </div>
       </div>
       <div class="col-md-4">
       <div class="mb-3">
        <label for="sale_manager" class="form-label">Sale Manager</label>
        <input type="text" id="sale_manager" required name="sale_manager" class="form-control form-control-sm" placeholder="" />
        <span class="text-danger custom-error">
         <?php if( isset($validation)  && $validation->hasError('sale_manager')){
         echo $validation->getError('sale_manager'); } ?>
        </span>
        </div>
       </div>
      </div>
      <div class="d-flex justify-content-center">
      <input type="submit" id="customer_profile_save_button" class="btn btn-success btn-sm mbtn" value="Save &amp; Next">
      </div>
    </form>
</div>
</div>
</div>
<? $this->endSection() ?>