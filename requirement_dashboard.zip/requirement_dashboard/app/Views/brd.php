<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>
<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style"> Business Requirements Document(BRD)</h2>
  <div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">
<a href="<?=base_url();?>add-brd" class="btn btn-primary btn-sm mbtn float-end"><i class="fa fa-plus"></i> Add BRD</a>
<table class="table table-sm">
<thead>
<tr>
   <th>Process</th>
   <th>Usage</th>
   <th>Requirement Heading</th>
   <th>Requirement Description</th>
   <th>Action</th>
</tr>
</thead>
<tbody>
 <?php
   foreach($brd_data as $val){
      ?>
      <tr>
         <td><?=$val["process"];?></td>
         <td><?=$val["product_usage"];?></td>
         <td><?=$val["requirement_heading"];?></td>
         <td><?=$val["requirement_description"];?></td>
         <td>
         <a href="#!" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a> 
         <a href="#!" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a> </td>
      </tr>
      <?php 
   } 
 ?>
</tbody>
</table>

      <div class="d-flex justify-content-center">
      <a href="<?=base_url();?>customer_profile" class="btn btn-primary btn-sm mbtn m-1"> <i class="fa fa-arrow-left"></i> Back</a>
      <a href="<?=base_url();?>product-backlog" class="btn btn-success btn-sm mbtn m-1">Next <i class="fa fa-arrow-right"></i></a>
      </div>

</div>
</div>
</div>
<? $this->endSection() ?>