<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>

<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style"> Customer Profile </h2>
<div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">


<table class="table table-bordered table-stripped">
<tr>
    <th>Customer Name / Acc. No.</th>
    <td><?= $customer[0]["crm_account_name_number"];?></td>
    <th>SPOC Name</th>
    <td><?= $customer[0]["spoc_name"];?></td>
</tr>
<tr>
    <th>SPOC Phone Number</th>
    <td><?= $customer[0]["spoc_phone_number"];?></td>
    <th>SPOC Email</th>
    <td><?= $customer[0]["spoc_email"];?></td>
</tr>

<tr>
    <th>B.A. Name</th>
    <td><?= $customer[0]["ba_name"];?></td>
    <th>B.A. Phone Number</th>
    <td><?= $customer[0]["ba_phone_number"];?></td>
</tr>
<tr>
    <th>B.A. Email</th>
    <td><?= $customer[0]["ba_email"];?></td>
    <th>Industry Name</th>
    <td><?= $customer[0]["industry_name"];?></td>
</tr>
<tr>
    <th>Proposed System</th>
    <td><?= $customer[0]["proposed_system"];?></td>
    <th>Set Up</th>
    <td><?= $customer[0]["set_up"];?></td>
</tr>
<tr>
    <th>Product Name</th>
    <td><?= $product_name[0]["product_name"];?></td>
    <th>Product Version</th>
    <td><?= $product_version[0]["product_version"];?></td>
</tr>
<tr>
    <th>Product Usage</th>
    <td><?= $customer[0]["product_usage"];?></td>
    <th>Sale Manager</th>
    <td><?= $customer[0]["sale_manager"];?></td>
</tr>


</table>

   <br />
    <div class="d-flex justify-content-center">
    <a href="<?=base_url();?>brd" class="btn  btn-primary mbtn btn-sm m-1"> Next <i class="fa fa-arrow-right"></i> </a>  
    </div>
</div>
</div>
</div>

<?php $this->endSection(); ?>