<? $this->extend('layout/dashboard-base'); ?>
<? $this->section('loginContent'); ?>
<br />
<div class="container">
<div class="card">
<div class="card-header customer-card-header p-3">
  <h2 class="h2-style"> Product Backlog </h2>
  <div class="text-white text-center"> <?= session()->get('customer_name'); ?> Ticket Number: <?=session()->get('ticket_number');?> </div>
</div>
<div class="card-body">
<a href="<?=base_url();?>add-product-backlog" class="btn btn-primary btn-sm mbtn float-end"><i class="fa fa-plus"></i> Add Product Backlog </a>

<table class="table table-sm">
<thead>
<tr>
   <th>User Story ID</th>
   <th>User Story</th>
   <th>Priority</th>
   <th>Module</th>
   <th>Sub Module</th>
   <th>Feature Name</th>
   <th>Estimated Hours</th>
   <th>Task Owner</th>
   <th>Action</th>
</tr>
</thead>
<tbody>
 <?php
   foreach($product_backlog_array as $val){
      ?>
      <tr>
         <td><?=$val["user_story_id"];?></td>
         <td><b><?=$val["as_a"];?></b>
          <div><?=$val["task_heading"];?></div>
          <div><?=$val["task_description"];?></div>
         </td>
         <td><?=$val["priority"];?></td>
         <td><?=$val["module"];?></td>
         <td><?=$val["sub_module"];?></td>
         <td><?=$val["feature_name"];?></td>
         <td><?=$val["estimated_hours"];?></td>
         <td><?=$val["task_owner"];?></td>
         <td>
         <a href="#!" class="btn btn-sm btn-success">Sprint Backlog</a>
          <div>
         <a href="#!" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a> 
         <a href="#!" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a> </td>
          </div> 
        </td>     
        </tr>
      <?php 
   } 
 ?>
</tbody>
</table>

      <div class="d-flex justify-content-center">
      <a href="<?=base_url();?>brd" class="btn btn-primary btn-sm mbtn m-1"> <i class="fa fa-arrow-left"></i> Back</a>
      <a href="#!" class="btn btn-success btn-sm mbtn m-1">Next <i class="fa fa-arrow-right"></i></a>
      </div>
</div>
</div>
</div>
<? $this->endSection() ?>